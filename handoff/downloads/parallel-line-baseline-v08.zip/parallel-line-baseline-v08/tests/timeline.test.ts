import {test} from 'node:test';
import assert from 'node:assert/strict';
import {SHOTS,TOTAL_FRAMES,DIALOGUE,REJECT_FRAME,phoneState,breathOffset,cityGain} from '../src/timeline';
import {cameraAt,makeProject} from '../src/projection';

test('seven shots cover exactly 1530 frames without gaps or overlaps',()=>{
  let end=0;
  for(const shot of SHOTS){assert.equal(shot.start,end);end+=shot.frames;}
  assert.equal(end,TOTAL_FRAMES);
});
test('dialogue respects the one-second pause and declined-call dream narrative',()=>{
  assert.equal(DIALOGUE[1].start-DIALOGUE[0].end,30);
  assert.ok(DIALOGUE[1].end<=REJECT_FRAME);
  assert.ok(DIALOGUE[2].start>REJECT_FRAME);
  assert.equal(phoneState(REJECT_FRAME-1),'incoming');
  assert.equal(phoneState(REJECT_FRAME),'declined');
  assert.equal(phoneState(1200),'declined');
});
test('city gain follows specified arc and ends silent',()=>{
  assert.ok(cityGain(180)>cityGain(299));
  assert.ok(cityGain(299)>cityGain(0));
  assert.equal(cityGain(300),cityGain(719));
  assert.equal(cityGain(1529),0);
});
test('breathing starts after dialogue, is subtle, and is reproducible',()=>{
  assert.equal(breathOffset(1259),0);
  for(let f=1260;f<1380;f++)assert.ok(Math.abs(breathOffset(f))<=2.5);
  assert.equal(breathOffset(1301),breathOffset(1301));
});
test('camera reaches hero continuously with finite projections and a fixed map',()=>{
  const end=cameraAt(299);
  assert.deepEqual(end.target,[350,350,145]);
  assert.ok(end.pitch<.04);
  let last:ReturnType<ReturnType<typeof makeProject>['project']>|undefined;
  for(let f=0;f<300;f++){
    const p=makeProject(cameraAt(f)).project([350,350,126]);
    assert.ok(Number.isFinite(p.x)&&Number.isFinite(p.y)&&p.depth>0);
    if(last)assert.ok(Math.hypot(p.x-last.x,p.y-last.y)<15);
    last=p;
  }
});
