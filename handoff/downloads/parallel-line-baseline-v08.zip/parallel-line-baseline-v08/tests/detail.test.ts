import {test} from 'node:test';
import assert from 'node:assert/strict';
import {phoneAction,POCKET_MOUTH,PHONE_HEIGHT} from '../src/detail/action';
import {detailedScene} from '../src/detail/scene';
import {createFieldFromShapes,NX,NY} from '../src/parallel/field';
const distance=(a:{y:number;z:number},b:{y:number;z:number})=>Math.hypot(a.y-b.y,a.z-b.z);
test('left phone reach preserves arm lengths and elbow orientation throughout extraction and return',()=>{
  for(let f=0;f<180;f++){
    const a=phoneAction(f),arm=a.pose.arms[1];
    assert.equal(arm.hand.x,.215);
    assert.ok(Math.abs(distance(arm.shoulder,arm.elbow)-.29)<1e-9);
    assert.ok(Math.abs(distance(arm.elbow,arm.hand)-.28)<1e-9);
    const dy=arm.hand.y-arm.shoulder.y,dz=arm.hand.z-arm.shoulder.z;
    const t=((arm.elbow.y-arm.shoulder.y)*dy+(arm.elbow.z-arm.shoulder.z)*dz)/(dy*dy+dz*dz);
    assert.ok(arm.elbow.z<arm.shoulder.z+t*dz);
  }
});
test('one phone emerges from the pocket, stays attached during reading and is occluded on return',()=>{
  let last=phoneAction(0);
  for(let f=1;f<180;f++){
    const a=phoneAction(f);
    assert.equal(a.phone.id,last.phone.id);
    assert.ok(Math.abs(a.phone.top-a.phone.bottom-PHONE_HEIGHT)<1e-9);
    assert.ok(distance(a.phone.center,last.phone.center)<.02,'No position teleport');
    assert.equal(a.phone.exposed===0,a.phone.top<=POCKET_MOUTH);
    if(f>=66&&f<112){assert.equal(a.phone.exposed,1);assert.ok(Math.abs(a.phone.center.z-a.wrist.z-.055)<1e-9);}
    last=a;
  }
  assert.equal(phoneAction(179).phone.exposed,0);
});
test('color ownership and ordered line field survive overlap and phone closeups',()=>{
  for(const frame of [38,130,178,235]){
    const scene=detailedScene(frame),field=createFieldFromShapes(scene.shapes,frame);
    for(let i=0;i<NX;i+=9)for(let j=1;j<NY;j++)assert.ok(field.flow[j*NX+i]>field.flow[(j-1)*NX+i]);
    assert.ok(field.role.some(r=>r===1));
    if(frame===38){assert.ok(field.role.some(r=>r===2));assert.ok(field.role.some(r=>r===3));}
    if(frame===178)assert.ok(field.role.some(r=>r===4));
  }
  const a=detailedScene(178),b=detailedScene(178);
  assert.deepEqual(createFieldFromShapes(a.shapes,178).flow,createFieldFromShapes(b.shapes,178).flow);
});
