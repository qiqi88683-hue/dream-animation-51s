import {test} from 'node:test';
import assert from 'node:assert/strict';
import {gaitPose,footPose,CYCLE,THIGH,SHIN} from '../src/spatial/gait';
const distance=(a:{x:number;y:number;z:number},b:{x:number;y:number;z:number})=>Math.hypot(a.x-b.x,a.y-b.y,a.z-b.z);
test('stance foot stays fixed in world space while body moves',()=>{
  for(const leg of [0,1])for(const speed of [.95,.85/.95,.88/.93]){
    for(let i=1;i<2400;i++){
      const t=i/300,prev=t-1/300,a=footPose(prev,leg,speed),b=footPose(t,leg,speed);
      if(a.stance&&b.stance&&b.phase>a.phase){
        assert.ok(Math.abs((prev*speed+a.z)-(t*speed+b.z))<1e-9);
        assert.equal(a.y,.065);assert.equal(b.y,.065);
      }
    }
  }
});
test('joint lengths stay constant and swing foot clears ground for the entire preview',()=>{
  let maxLift=0;
  for(let i=0;i<240;i++)for(const speed of [.95,.85/.95,.88/.93]){
    const pose=gaitPose(i/30,speed);
    for(const leg of pose.legs){
      assert.ok(Math.abs(distance(leg.hip,leg.knee)-THIGH)<1e-9);
      assert.ok(Math.abs(distance(leg.knee,leg.ankle)-SHIN)<1e-9);
      assert.ok(leg.ankle.y>=.065);maxLift=Math.max(maxLift,leg.ankle.y-.065);
    }
  }
  assert.ok(maxLift>.10);
  assert.deepEqual(gaitPose(CYCLE,.95),gaitPose(CYCLE,.95));
});

test('knees bend forward and elbows backward in the local anatomical frame',()=>{
  // Local +Z is forward. A bend is measured against the joint's orthogonal
  // projection on the endpoint chord, not against the ankle/hand position.
  const offset=(start:{y:number;z:number},end:{y:number;z:number},joint:{y:number;z:number})=>{
    const dy=end.y-start.y,dz=end.z-start.z;
    const t=((joint.y-start.y)*dy+(joint.z-start.z)*dz)/(dy*dy+dz*dz);
    return joint.z-(start.z+t*dz);
  };
  for(let frame=0;frame<240;frame++){
    const p=gaitPose(frame/30,.95);
    for(const leg of p.legs)assert.ok(offset(leg.hip,leg.ankle,leg.knee)>0,'Knee must bow toward +Z');
    for(const arm of p.arms)assert.ok(offset(arm.shoulder,arm.hand,arm.elbow)<0,'Elbow must bow toward -Z');
  }
});
