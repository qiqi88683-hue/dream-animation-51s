import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createField,NX,NY} from '../src/parallel/field';

test('parallel field remains ordered and finite throughout the walk',()=>{
  for(const frame of [0,28,70,120,179,239]){
    const field=createField(frame);
    for(let i=0;i<NX;i+=5)for(let j=1;j<NY;j++){
      const a=field.flow[(j-1)*NX+i],b=field.flow[j*NX+i];
      assert.ok(Number.isFinite(b)&&b>a,'Parallel lines must not cross or fold');
    }
    assert.ok(field.dark.some(v=>v>.8),'Dense dark regions must exist');
    assert.ok(field.dark.some(v=>v===0),'Open paper regions must exist');
  }
});
test('parallel field at the same frame is reproducible and changes with gait',()=>{
  const a=createField(30),b=createField(30),c=createField(48);
  assert.deepEqual(a.flow,b.flow);assert.notDeepEqual(a.flow,c.flow);
});
