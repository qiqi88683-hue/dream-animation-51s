import {test} from 'node:test';
import assert from 'node:assert/strict';
import {heroAt,heroPose,crowdAt,filmCamera,localToWorld} from '../src/film/model';
import {povForeground} from '../src/film/pov';
import {filmScene} from '../src/film/scene';
import {createFieldFromShapes,NX,NY,type Shape} from '../src/parallel/field';
import cues from '../src/film/voice-cues.json';
import {SHOTS,TOTAL_FRAMES} from '../src/timeline';
const distance=(a:{x:number;y:number;z:number},b:{x:number;y:number;z:number})=>Math.hypot(a.x-b.x,a.y-b.y,a.z-b.z);
test('planted feet stay fixed in world coordinates while crossing and approaching bench diagonally',()=>{
 for(const [start,end] of [[301,479],[481,619]])for(let f=start;f<=end;f++){
  const before=heroPose(f-1),now=heroPose(f),rootA=heroAt(f-1),rootB=heroAt(f);
  for(const i of [0,1])if(before.legs[i].stance&&now.legs[i].stance&&now.legs[i].phase>before.legs[i].phase){
   const a=localToWorld(rootA,rootA.heading,before.legs[i].ankle),b=localToWorld(rootB,rootB.heading,now.legs[i].ankle);
   assert.ok(Math.hypot(a[0]-b[0],a[1]-b[1])<1e-7,'Support foot must not drift sideways or along route');
  }
 }
});
test('full film has continuous world route, stable crowd identities and reachable articulated joints',()=>{
 assert.equal(TOTAL_FRAMES,1530);assert.equal(SHOTS.reduce((n,s)=>n+s.frames,0),1530);
 for(let f=0;f<720;f++){
  const pose=heroPose(f),root=heroAt(f);
  assert.ok(Number.isFinite(root.x)&&Number.isFinite(root.y));
  for(const a of pose.arms){assert.ok(Math.abs(distance(a.shoulder,a.elbow)-.29)<1e-8);assert.ok(Math.abs(distance(a.elbow,a.hand)-.28)<1e-8);}
  for(const a of pose.legs){assert.ok(Math.abs(distance(a.hip,a.knee)-.48)<1e-8);assert.ok(Math.abs(distance(a.knee,a.ankle)-.47)<1e-8);}
  if(f>0&&f!==300&&f!==480){const before=heroAt(f-1);assert.ok(Math.hypot(root.x-before.x,root.y-before.y)<4.0);}
 }
 assert.equal(heroAt(0).x,350);assert.equal(heroAt(479).x,-345);assert.equal(heroAt(719).x,-435);
 const start=crowdAt(0),end=crowdAt(1529);assert.equal(start.length,30);assert.deepEqual(start.map(p=>p.id),end.map(p=>p.id));
 for(let f=1;f<1530;f+=30){const prev=crowdAt(f-1),now=crowdAt(f);for(let i=0;i<now.length;i++){assert.ok(Math.abs(Math.abs(now[i].x-prev[i].x)-now[i].speed*100/30)<1e-8);assert.equal(now[i].y,prev[i].y);}}
});
test('story camera reverses from hero back to frontal view; POV decline contact stays on button',()=>{
 assert.ok(Math.abs(filmCamera(0).pitch-Math.PI/2)<1e-9);assert.ok(filmCamera(299).yaw<0);assert.ok(filmCamera(300).yaw>0);
 const shapes:Shape[]=[],ui=povForeground(1116,shapes,[]);
 assert.equal(ui.state,'declined');assert.equal(shapes.filter(s=>s.feature==='hero-phone').length,1);
 assert.equal(cues[1].start-cues[0].end,30);assert.ok(cues[2].start>1116);assert.ok(cues[2].end<1260);
 assert.deepEqual(cues.map(c=>c.text),['你觉得他能接吗？','可能会吧。','唉，看来还是不想见我。']);
});
test('all seven shots have finite non-crossing fields, including camera descent and dense crowd',()=>{
 for(const f of [0,150,299,400,650,800,930,1290,1529]){
  const scene=filmScene(f),field=createFieldFromShapes(scene.shapes,scene.frame);
  assert.ok(scene.shapes.length>60);
  for(let x=0;x<NX;x+=13)for(let y=1;y<NY;y++)assert.ok(Number.isFinite(field.flow[y*NX+x])&&field.flow[y*NX+x]>field.flow[(y-1)*NX+x]);
 }
});
