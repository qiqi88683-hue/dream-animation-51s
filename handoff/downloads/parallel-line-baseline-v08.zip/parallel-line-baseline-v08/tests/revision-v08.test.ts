import {test} from 'node:test';
import assert from 'node:assert/strict';
import {phoneUI} from '../src/film/Film';
import {endingAt} from '../src/film/ending';
import {filmScene} from '../src/film/scene';
import {heroPose,heroAt,localToWorld,filmCamera} from '../src/film/model';
import {makeProject} from '../src/projection';
import {createFieldFromShapes,NX,NY,DX} from '../src/parallel/field';

test('caller rendering contains no numeric text in any phone state',()=>{
 for(const state of ['incoming','music','declined'] as const){
  const text:string[]=[];
  const ctx=new Proxy({}, {get:(_t,key)=>key==='measureText'?(s:string)=>({width:s.length*10}):key==='fillText'?(s:string)=>text.push(s):()=>{}}) as CanvasRenderingContext2D;
  phoneUI(ctx,{center:{x:0,y:0},width:226,height:402,angle:0,state,visible:1});
  assert.ok(text.length>0);assert.ok(text.every(s=>!/[0-9０-９]/.test(s)),'A blurred caller must never be backed by digits');
 }
});
test('road planes cannot occlude both legs at the formerly broken frontal walk frames',()=>{
 for(const f of [300,320,340,360,380]){
  const scene=filmScene(f),field=createFieldFromShapes(scene.shapes,f),r=heroAt(f),pose=heroPose(f),project=makeProject(filmCamera(f)).project;
  for(const leg of pose.legs)for(const point of [leg.knee,leg.ankle]){
   const q=project(localToWorld(r,r.heading,point)),x=Math.round(q.x/DX);let lo=0,hi=NY-1;
   while(hi-lo>1){const mid=(lo+hi)>>1;if(field.flow[mid*NX+x]<q.y)lo=mid;else hi=mid;}
   assert.equal(field.role[lo*NX+x],1,'The visible leg center must belong to the hero, not a ground polygon');
  }
 }
});
test('walking shoes stay inside the viewport through crossing and bench approach',()=>{
 for(let f=300;f<620;f++){
  const r=heroAt(f),p=makeProject(filmCamera(f)).project;
  for(const leg of heroPose(f).legs)for(const z of [-.025,.12]){
   const q=p(localToWorld(r,r.heading,{...leg.ankle,y:.005,z:leg.ankle.z+z}));
   assert.ok(q.x>100&&q.x<1820&&q.y>0&&q.y<1040);
  }
 }
});
test('signal disturbance is confined to the final shot, deterministic, gentle and resolves to white',()=>{
 for(const f of [0,930,1379,1380]){const e=endingAt(f);assert.equal(e.strength,0);assert.equal(e.shakeX,0);assert.equal(e.shakeY,0);}
 for(let f=1380;f<1530;f++){const e=endingAt(f);assert.ok(Math.abs(e.shakeX)<=3.08&&Math.abs(e.shakeY)<=1.4);assert.deepEqual(e,endingAt(f));}
 assert.ok(endingAt(1440).strength>.5);assert.equal(endingAt(1529).strength,0);assert.equal(endingAt(1529).fade,1);
});
