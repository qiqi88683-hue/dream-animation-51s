import {bundle} from '@remotion/bundler';
import {renderStill,renderMedia,selectComposition} from '@remotion/renderer';
import {existsSync,mkdirSync,readFileSync,renameSync,writeFileSync,readdirSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const out=path.join(root,'out/film-v08');mkdirSync(out,{recursive:true});mkdirSync(path.join(out,'shots'),{recursive:true});
const serveUrl=await bundle({entryPoint:path.join(root,'src/index.ts'),publicDir:path.join(root,'public')});
const walk=d=>readdirSync(d,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(path.join(d,e.name)):[path.join(d,e.name)]);
const sourceFiles=[...walk(path.join(root,'src')),path.join(root,'scripts/render-film.mjs'),path.join(root,'public/fonts/NotoSansCJKsc-Regular.otf')];
const fingerprint=createHash('sha256');for(const f of sourceFiles.sort())fingerprint.update(path.relative(root,f)).update(readFileSync(f));const sourceHash=fingerprint.digest('hex');
const sceneFingerprint=JSON.parse(execFileSync('node',['--import','tsx',path.join(root,'scripts/film-fingerprint.ts')],{cwd:root,encoding:'utf8'}));
const errors=[];
const common={serveUrl,browserExecutable:process.env.REMOTION_BROWSER_EXECUTABLE||(existsSync('/usr/bin/chromium')?'/usr/bin/chromium':undefined),timeoutInMilliseconds:90000,
 onBrowserLog:log=>{if(log.type==='error')errors.push(log.text||'browser error');}};
const quick=process.argv.includes('--quick'),stills=process.argv.includes('--stills-only'),videoOnly=process.argv.includes('--videos-only');
if(!videoOnly){
 const frames=quick?[320,560,930,1422,1455,1490]:[0,100,190,299,300,320,340,360,380,400,460,480,520,560,600,650,710,735,800,930,1116,1200,1290,1380,1410,1422,1455,1460,1490,1529];
 const composition=await selectComposition({...common,id:'FilmFull'});
 for(const frame of frames){
  const name=`frame-${String(frame).padStart(4,'0')}.png`;
  await renderStill({...common,composition,inputProps:{sound:false,captions:false},output:path.join(out,name),frame,imageFormat:'png'});console.log('Saved',name);
 }
 if(quick||stills)process.exit(0);
 await renderStill({...common,composition,inputProps:{sound:false,captions:false},output:path.join(out,'repeat-0930.png'),frame:930,imageFormat:'png'});
 const hash=f=>createHash('sha256').update(readFileSync(f)).digest('hex');
 if(hash(path.join(out,'frame-0930.png'))!==hash(path.join(out,'repeat-0930.png')))throw Error('Independent frame hash differs');
 writeFileSync(path.join(out,'still-verification.json'),JSON.stringify({frame:930,determinism:true,sha256:hash(path.join(out,'frame-0930.png')),browserErrors:errors},null,2));
}
const starts=[0,300,480,720,840,1140,1380],frames=[300,180,240,120,300,240,150];
for(let i=0;i<7;i++){
 const name=`shot-${String(i+1).padStart(2,'0')}.mp4`,dest=path.join(out,'shots',name);
 if(existsSync(dest)&&existsSync(dest+'.json')&&JSON.parse(readFileSync(dest+'.json')).semanticHash===sceneFingerprint.shots[i].semanticHash&&!process.argv.includes('--force')){console.log('Resume: kept',name);continue;}
 const id=`FilmShot0${i+1}`,composition=await selectComposition({...common,id,inputProps:{captions:false}});let last=-1;
 await renderMedia({...common,composition,inputProps:{captions:false},codec:'h264',crf:22,pixelFormat:'yuv420p',concurrency:2,muted:true,outputLocation:dest+'.partial.mp4',
  onProgress:({progress})=>{const n=Math.floor(progress*5);if(n!==last){last=n;console.log(`${name}: ${n*20}%`);}}});
 if(errors.length)throw new Error(errors.join('\n'));
 renameSync(dest+'.partial.mp4',dest);
 writeFileSync(dest+'.json',JSON.stringify({id,sourceHash,baseHash:sceneFingerprint.baseHash,semanticHash:sceneFingerprint.shots[i].semanticHash,start:starts[i],frames:frames[i],width:1920,height:1080,fps:30,codec:'h264',browserErrors:errors},null,2));
}
const list=path.join(out,'shots.txt');writeFileSync(list,starts.map((_,i)=>`file 'shots/shot-${String(i+1).padStart(2,'0')}.mp4'`).join('\n')+'\n');
execFileSync('ffmpeg',['-v','error','-y','-f','concat','-safe','0','-i',list,'-i',path.join(root,'public/audio/film-v08/full-mix.wav'),'-map','0:v:0','-map','1:a:0','-c:v','copy','-c:a','aac','-b:a','192k','-t','51','-movflags','+faststart',path.join(out,'dream-51s-1080p.mp4')]);
console.log('PASS joined seven shots, muxed the continuous 51s stereo mix');
