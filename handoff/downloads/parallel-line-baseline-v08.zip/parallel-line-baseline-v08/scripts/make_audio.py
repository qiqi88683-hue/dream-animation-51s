"""Original deterministic sound-design placeholders; not recorded traffic or crowd voices."""
from pathlib import Path
import math, random, struct, wave

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'public/audio/generated'
OUT.mkdir(parents=True, exist_ok=True)
RATE = 24000

def save(name, seconds, sample):
    with wave.open(str(OUT / name), 'wb') as f:
        f.setparams((2, 2, RATE, 0, 'NONE', 'not compressed'))
        chunk = bytearray()
        for n in range(round(seconds * RATE)):
            left, right = sample(n / RATE)
            chunk.extend(struct.pack('<hh', *(round(max(-.95, min(.95, v))*32767) for v in (left,right))))
            if len(chunk) >= 96000:
                f.writeframes(chunk)
                chunk.clear()
        if chunk: f.writeframes(chunk)
    print(OUT / name)

rng = random.Random(51)
low = [0., 0.]
def city(t):
    result=[]
    for ch in range(2):
        low[ch]=low[ch]*.96 + rng.uniform(-1,1)*.04
        passing=.3+.7*math.sin(t*.39+ch*.5)**2
        hum=math.sin(2*math.pi*58*t)*.017 + math.sin(2*math.pi*93*t)*.011
        result.append(low[ch]*passing*.5+hum)
    return result

def ring(t):
    # Soft two-tone phone pulse, with short attack/release, ending before rejection.
    phase=t%2.4
    gate=max(0,min(1,phase/.025,(.65-phase)/.04)) if phase<.65 else 0
    tone=(math.sin(2*math.pi*523.25*t)+math.sin(2*math.pi*659.25*t))*.12*gate
    return tone,tone

save('city-placeholder.wav',51,city)
save('ring-placeholder.wav',9.2,ring)
