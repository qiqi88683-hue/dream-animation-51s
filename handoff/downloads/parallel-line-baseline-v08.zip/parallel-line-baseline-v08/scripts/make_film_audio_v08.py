"""v08: original non-vocal sound design only. No TTS dependency or voice files."""
from pathlib import Path
import json,hashlib
import numpy as np
import soundfile as sf
R=Path(__file__).resolve().parents[1];O=R/'public/audio/film-v08';O.mkdir(parents=True,exist_ok=True)
SR=48000;N=51*SR;rng=np.random.default_rng(510730);t=np.arange(N)/SR
noise=rng.standard_normal(N).astype(np.float32)
def lowpass(x,w):return np.convolve(x,np.ones(w,dtype=np.float32)/w,mode='same')
def sm(x):x=np.clip(x,0,1);return x*x*(3-2*x)
traffic=lowpass(noise,34)*.09+lowpass(noise,240)*.18
for j in range(9):
 center=2+j*5.5;env=np.exp(-((t-center)/1.6)**2)
 traffic+=.013*env*(np.sin(2*np.pi*(72+4*np.sin(t*.4))*t)+.5*np.sin(2*np.pi*131*t))
gain=np.where(t<6,.55+.9*sm(t/6),np.where(t<10,1.45-.65*sm((t-6)/4),np.where(t<24,.80,np.where(t<28,.14,.48))))
parts={};
def layer(name):parts[name]=np.zeros((N,2),np.float32);return parts[name]
parts['traffic']=np.stack([traffic*gain,np.roll(traffic,37)*gain],axis=1).astype(np.float32)
def add(dest,audio,at,volume=1):
 start=int(at*SR);arr=np.asarray(audio,dtype=np.float32)
 if arr.ndim==1:arr=np.stack([arr,arr],axis=1)
 n=min(len(arr),N-start)
 if n>0:dest[start:start+n]+=arr[:n]*volume
foley=layer('footsteps-and-bench')
for sec in np.arange(10.22,20.64,.56):
 x=np.arange(int(SR*.16))/SR;step=lowpass(rng.standard_normal(len(x)).astype(np.float32),12)*np.exp(-x*36)*.10
 step+=np.sin(2*np.pi*92*x)*np.exp(-x*44)*.035;add(foley,step,sec,.65)
x=np.arange(int(SR*.38))/SR;creak=(np.sin(2*np.pi*(170+np.sin(x*13)*30)*x)*.028+lowpass(rng.standard_normal(len(x)).astype(np.float32),25)*.04)*np.sin(np.pi*x/.38)**2;add(foley,creak,22.25)
music=layer('earphone-instrumental')
for j,hz in enumerate([293.665,369.994,440,493.883,440,369.994,329.628,293.665]):
 x=np.arange(int(SR*.75))/SR;note=(np.sin(2*np.pi*hz*x)+.3*np.sin(2*np.pi*hz*2*x))*np.exp(-x*5)*.052
 at=24.35+j*.44;add(music,note[:max(0,int((28-at)*SR))],at)
phone=layer('phone-ring-and-vibration')
for sec in np.arange(28,1116/30,.95):
 x=np.arange(int(SR*.37))/SR;ring=(np.sin(2*np.pi*659.25*x)+.6*np.sin(2*np.pi*783.99*x))*np.sin(np.pi*x/.37)**2*.047
 vib=np.sin(2*np.pi*122*x)*.026*np.sin(np.pi*x/.37)**2
 n=min(len(ring),int((1116/30-sec)*SR));add(phone,(ring+vib)[:n],sec)
x=np.arange(int(SR*.065))/SR;add(phone,np.sin(2*np.pi*620*x)*np.exp(-x*75)*.045,1116/30)
fade=1-sm((t-46)/(5-1/SR));mix=np.zeros((N,2),np.float32);stems=[]
for name,arr in parts.items():
 arr*=fade[:,None]*2.3;mix+=arr;dest=O/(name+'.wav');sf.write(dest,arr,SR,subtype='PCM_16')
 stems.append({'name':name,'file':dest.name,'sha256':hashlib.sha256(dest.read_bytes()).hexdigest()})
peak=float(np.max(np.abs(mix)));assert peak<.98 and np.all(mix[-1]==0)
sf.write(O/'full-mix.wav',mix,SR,subtype='PCM_16')
record={'date':'2026-10-27','request':'Remove all vocal audio','included':[s['name'] for s in stems],'excluded':['synthetic dialogue','crowd murmur','human breathing','dialogue reverb','dialogue captions'],'vocal_sources':[],'tts_used':False,'sources':'Original deterministic program synthesis only; no human or vocal recordings','stems':stems,'mix':{'sample_rate':SR,'samples':N,'seconds':51,'stereo':True,'peak':peak,'final_sample_zero':True,'sha256':hashlib.sha256((O/'full-mix.wav').read_bytes()).hexdigest()}}
(O/'provenance.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print('PASS v08 non-vocal 51s stereo mix; vocal sources absent; peak',peak,flush=True)
