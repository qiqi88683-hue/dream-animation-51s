import {bundle} from '@remotion/bundler';
import {renderStill,renderMedia,selectComposition} from '@remotion/renderer';
import {existsSync,mkdirSync,readFileSync,renameSync,writeFileSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const out=path.join(root,'out/parallel-v05');mkdirSync(out,{recursive:true});
const serveUrl=await bundle({entryPoint:path.join(root,'src/index.ts'),publicDir:path.join(root,'public')});
const errors=[];
const common={serveUrl,browserExecutable:process.env.REMOTION_BROWSER_EXECUTABLE||(existsSync('/usr/bin/chromium')?'/usr/bin/chromium':undefined),timeoutInMilliseconds:60000,
  onBrowserLog:log=>{if(log.type==='error')errors.push(log.text||'browser error');}};
const quick=process.argv.includes('--quick');
const frames=quick?[['ParallelPreview',0,'frame-000']]:[['ParallelPreview',0,'frame-000'],['ParallelPreview',38,'frame-038'],['ParallelPreview',90,'frame-090'],['ParallelPreview',179,'frame-179'],['ParallelPortrait',0,'monochrome-portrait'],['GaitCheck',0,'joint-directions'],['ParallelPreview',90,'repeat-090']];
for(const [id,frame,name] of frames){
  const composition=await selectComposition({...common,id});
  await renderStill({...common,composition,output:path.join(out,`${name}.png`),frame,imageFormat:'png'});
  console.log(`Saved ${name}.png`);
}
if(errors.length)throw new Error(errors.join('\n'));
if(quick)process.exit(0);
const hash=file=>createHash('sha256').update(readFileSync(file)).digest('hex');
if(hash(path.join(out,'frame-090.png'))!==hash(path.join(out,'repeat-090.png')))throw new Error('Parallel field independent-frame hash mismatch');
if(process.argv.includes('--stills-only'))process.exit(0);
const composition=await selectComposition({...common,id:'ParallelPreview'});
let last=-1;
await renderMedia({...common,composition,codec:'h264',crf:19,pixelFormat:'yuv420p',audioCodec:'aac',concurrency:2,outputLocation:path.join(out,'preview.partial.mp4'),
  onProgress:({progress})=>{const n=Math.floor(progress*10);if(n!==last){last=n;console.log(`Parallel-line preview: ${n*10}%`);}}
});
if(errors.length)throw new Error(errors.join('\n'));
execFileSync('ffmpeg',['-v','error','-y','-i',path.join(out,'preview.partial.mp4'),'-c','copy','-movflags','+faststart',path.join(out,'faststart.partial.mp4')]);
renameSync(path.join(out,'faststart.partial.mp4'),path.join(out,'parallel-preview-1080p.mp4'));
writeFileSync(path.join(out,'verification.json'),JSON.stringify({createdAt:new Date().toISOString(),composition:'ParallelPreview',width:1920,height:1080,fps:30,frames:240,seconds:8,independentFrameHash:hash(path.join(out,'frame-090.png')),determinism:true,browserErrors:errors,method:'ordered continuous parallel-curve relief field; coarse strokes and local shadow line density; no painted image textures'},null,2)+'\n');
console.log('PASS parallel-line animation and frame consistency');
