import {createHash} from 'node:crypto';
import {readFileSync} from 'node:fs';
import {filmScene,FILM_PALETTE} from '../src/film/scene';
import {SHOTS} from '../src/timeline';
// Hash every frame's complete draw inputs plus the shared rasterizer, painter,
// font, subtitles and codec settings. An unrelated shot's route can change
// without invalidating the already rendered frames of another shot.
const base=createHash('sha256');
for(const f of ['src/film/Film.tsx','src/parallel/field.ts','src/timeline.ts','src/film/ending.ts','public/fonts/NotoSansCJKsc-Regular.otf'])base.update(f).update(readFileSync(f));
base.update(JSON.stringify(FILM_PALETTE)).update('1080p30 h264 crf22 yuv420p captions=false v08');
const baseHash=base.digest('hex');
const shots=SHOTS.map(shot=>{
 const h=createHash('sha256').update(baseHash);
 for(let frame=shot.start;frame<shot.start+shot.frames;frame++)h.update(JSON.stringify(filmScene(frame)));
 return {id:shot.id,start:shot.start,frames:shot.frames,semanticHash:h.digest('hex')};
});
process.stdout.write(JSON.stringify({baseHash,shots}));
