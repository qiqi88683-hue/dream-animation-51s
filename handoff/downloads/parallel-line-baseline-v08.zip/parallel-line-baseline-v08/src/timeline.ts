export const FPS = 30;
export const WIDTH = 1920;
export const HEIGHT = 1080;
export const SHOTS = [
  {id: 'Shot01', start: 0, frames: 300, status: 'prototype'},
  {id: 'Shot02', start: 300, frames: 180, status: 'not-started'},
  {id: 'Shot03', start: 480, frames: 240, status: 'not-started'},
  {id: 'Shot04', start: 720, frames: 120, status: 'not-started'},
  {id: 'Shot05', start: 840, frames: 300, status: 'prototype'},
  {id: 'Shot06', start: 1140, frames: 240, status: 'prototype'},
  {id: 'Shot07', start: 1380, frames: 150, status: 'not-started'},
] as const;
export const TOTAL_FRAMES = 1530;
// Prototype timing, not approved final dialogue durations. end is exclusive.
export const DIALOGUE = [
  {id: 'f1-question', speaker: '女主', text: '你觉得他能接吗？', start: 852, end: 927, file: 'f1-question.wav'},
  {id: 'f2-answer', speaker: '女二', text: '可能会吧。', start: 957, end: 1008, file: 'f2-answer.wav'},
  {id: 'f1-after', speaker: '女主', text: '唉，看来还是不想见我。', start: 1148, end: 1260, file: 'f1-after.wav'},
] as const;
export const REJECT_FRAME = 1116;
export const clamp = (x: number, lo = 0, hi = 1) => Math.max(lo, Math.min(hi, x));
export const mix = (a: number, b: number, t: number) => a + (b - a) * t;
export const smooth = (x: number) => {const t = clamp(x); return t * t * (3 - 2 * t);};
export const rand = (seed: number) => {const x = Math.sin(seed * 127.1 + 311.7) * 43758.5453; return x - Math.floor(x);};
export function phoneState(frame: number) {
  return frame < 840 ? 'music' : frame < REJECT_FRAME ? 'incoming' : 'declined';
}
export function breathOffset(frame: number) {
  return frame < 1260 ? 0 : Math.sin((frame - 1260) / FPS * Math.PI * 0.8) * 2.5 * smooth((frame - 1260) / 24);
}
export function cityGain(frame: number) {
  if (frame < 180) return mix(0.18, 0.55, smooth(frame / 180));
  if (frame < 300) return mix(0.55, 0.30, smooth((frame - 180) / 120));
  if (frame < 720) return 0.30;
  if (frame < 840) return 0.045;
  if (frame < 1380) return 0.15;
  return 0.15 * (1 - smooth((frame - 1380) / 149));
}
