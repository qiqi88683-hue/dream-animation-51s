import {mix, smooth} from './timeline';
export type V3 = [number, number, number];
export type Camera = {target: V3; yaw: number; pitch: number; distance: number};
export const cameraAt = (frame: number): Camera => {
  const t = smooth(frame / 225);
  const close = smooth((frame - 220) / 79);
  return {
    target: [mix(0, 350, t), mix(0, 350, t), mix(mix(0, 126, t), 145, close)],
    yaw: mix(0, -Math.PI / 2, t), pitch: mix(Math.PI / 2, .035, t),
    distance: mix(mix(2100, 350, t), 150, close),
  };
};
export function makeProject(camera: Camera) {
  const {yaw, pitch, target, distance} = camera;
  const right: V3 = [Math.cos(yaw), Math.sin(yaw), 0];
  const up: V3 = [Math.sin(yaw)*Math.sin(pitch), -Math.cos(yaw)*Math.sin(pitch), Math.cos(pitch)];
  const forward: V3 = [Math.sin(yaw)*Math.cos(pitch), -Math.cos(yaw)*Math.cos(pitch), -Math.sin(pitch)];
  const eye = target.map((v,i)=>v-forward[i]*distance) as V3;
  const project = (p: V3) => {
    const v=p.map((n,i)=>n-eye[i]);
    const depth=v.reduce((s,n,i)=>s+n*forward[i],0);
    const scale=1000/Math.max(15,depth);
    return {x:960+scale*v.reduce((s,n,i)=>s+n*right[i],0), y:540-scale*v.reduce((s,n,i)=>s+n*up[i],0), depth, scale};
  };
  return {project, right};
}
