import React,{useLayoutEffect,useRef} from 'react';
import {AbsoluteFill,Audio,staticFile,useCurrentFrame} from 'remotion';
import {createField,fieldSample,NX,DX,H,W,LINE_SPACING} from './field';

export function drawParallel(ctx:CanvasRenderingContext2D,frame:number,portrait=false,mono=false){
  const field=createField(frame,portrait);
  ctx.fillStyle=mono?'#ebe9e1':'#bdc8c7';ctx.fillRect(0,0,W,H);
  ctx.lineCap='round';ctx.lineJoin='round';
  const stroke=(points:{x:number;y:number}[])=>{
    if(points.length<2)return;ctx.beginPath();ctx.moveTo(points[0].x,points[0].y);
    for(let i=1;i<points.length-1;i++)ctx.quadraticCurveTo(points[i].x,points[i].y,(points[i].x+points[i+1].x)/2,(points[i].y+points[i+1].y)/2);
    ctx.lineTo(points.at(-1)!.x,points.at(-1)!.y);ctx.stroke();
  };
  // All visible volume is formed by the same continuous, ordered horizontal family.
  for(let row=0;row<=H/LINE_SPACING;row++){
    const y=row*LINE_SPACING;
    const points=Array.from({length:NX},(_,i)=>({x:i*DX,y:fieldSample(field.flow,i,y)}));
    ctx.strokeStyle=mono?'#303432':'#4a5e66';ctx.lineWidth=3.35;ctx.globalAlpha=.78;
    stroke(points);
    // The same curves darken through the figure; no new contour/fill is drawn.
    let part:{x:number;y:number}[]=[];
    ctx.strokeStyle=mono?'#141918':'#253d48';ctx.lineWidth=4.0;ctx.globalAlpha=.98;
    for(let i=0;i<NX;i++){
      if(fieldSample(field.coverage,i,y)>.24)part.push(points[i]);
      else{stroke(part);part=[];}
    }stroke(part);
  }
  ctx.globalAlpha=1;
}

export const ParallelPreview:React.FC<{mono:boolean;portrait:boolean}>=({mono,portrait})=>{
  const frame=useCurrentFrame(),canvas=useRef<HTMLCanvasElement>(null);
  useLayoutEffect(()=>{if(canvas.current)drawParallel(canvas.current.getContext('2d')!,frame,portrait,mono);},[frame,portrait,mono]);
  return <AbsoluteFill><canvas ref={canvas} width={W} height={H} style={{width:'100%',height:'100%'}}/>
    {!portrait&&<Audio src={staticFile('audio/generated/city-placeholder.wav')} volume={.20}/>}
  </AbsoluteFill>;
};
