import {gaitPose,type V} from '../spatial/gait';
import {clamp,smooth} from '../timeline';

export const W=1920,H=1080,DX=4,DY=3;
export const NX=W/DX+1,NY=H/DY+1;
export const LINE_SPACING=10.5;
export type P={x:number;y:number};
export type Shape={kind:'ellipse'|'capsule'|'rect'|'poly';a:P;b:P;rx:number;ry:number;depth:number;tone:number;body:boolean;detail?:boolean;role?:number;layer?:number;angle?:number;clipY?:number;feature?:string;points?:P[]};
export type Field={height:Float32Array;dark:Float32Array;flow:Float32Array;body:Float32Array;coverage:Float32Array;role:Float32Array};

export function characterProjection(frame:number,portrait=false){
  const time=frame/30,scale=portrait?570:340;
  const rootX=portrait?1000:1260-time*.95*scale*.2,ground=portrait?1420:1000;
  return {scale,rootX,ground,project:(v:V):P=>({x:rootX-v.z*scale+v.x*scale*.22,y:ground-v.y*scale})};
}
export function makeShapes(frame:number,portrait=false):Shape[]{
  const time=frame/30,p=gaitPose(time,.95),view=characterProjection(frame,portrait),s=view.scale,project=view.project;
  const shapes:Shape[]=[];
  const ellipse=(a:P,rx:number,ry:number,depth:number,tone:number,body=true,detail=false)=>shapes.push({kind:'ellipse',a,b:a,rx,ry,depth,tone,body,detail});
  const capsule=(a:P,b:P,r:number,depth:number,tone:number,body=true,detail=false)=>shapes.push({kind:'capsule',a,b,rx:r,ry:r,depth,tone,body,detail});
  const rect=(a:P,b:P,depth:number,tone:number,body=false,detail=false)=>shapes.push({kind:'rect',a,b,rx:0,ry:0,depth,tone,body,detail});
  if(!portrait){
    const camera=-time*.95*s*.8;
    // City masses are also made only from line displacement, with a quieter field.
    for(let i=-3;i<=6;i++){
      const x=260+i*240-camera*.30,top=150+(i%3)*54;
      rect({x,y:top},{x:x+180,y:515},.19,.20);
    }
    const bench=530-camera*.72;
    capsule({x:bench-110,y:670},{x:bench+110,y:670},12,.24,.3,false);
    capsule({x:bench-110,y:622},{x:bench+110,y:622},12,.22,.3,false);
    for(const side of [-1,1])capsule({x:bench+side*88,y:670},{x:bench+side*88,y:727},5,.15,.3,false);
    const pole=1710-camera*.62;
    capsule({x:pole,y:316},{x:pole,y:718},6,.2,.3,false);
    rect({x:pole-20,y:300},{x:pole+20,y:362},.25,.4,false);
    for(let i=-2;i<12;i++){
      const x=80+i*190-camera;
      capsule({x:x-75,y:1070},{x:x+55,y:940},13,.12,.16,false);
    }
  }
  // Rear limbs first; the near surfaces carry a slightly higher relief.
  for(const i of [0,1]){
    const leg=p.legs[i],near=i===1;
    capsule(project(leg.hip),project(leg.knee),s*.058,near?.95:.83,.78);
    capsule(project(leg.knee),project(leg.ankle),s*.041,near?.90:.78,.80);
    const ankle=project(leg.ankle);
    ellipse({x:ankle.x-s*.045,y:ankle.y+s*.025},s*.116,s*.035,.58,.53);
  }
  ellipse(project({x:0,y:p.pelvis+.285,z:.008}),s*.142,s*.320,1.14,.74);
  capsule(project({x:0,y:p.pelvis+.57,z:.008}),project({x:0,y:p.pelvis+.67,z:.015}),s*.035,.90,.40);
  const head=project({x:0,y:p.pelvis+.78,z:.012});
  ellipse(head,s*.073,s*.118,.96,.38);
  // Small cheek, nose, chin and fringe reliefs retain an ordinary side profile.
  ellipse({x:head.x-s*.068,y:head.y+s*.002},s*.031,s*.019,.70,.34);
  ellipse({x:head.x-s*.029,y:head.y+s*.072},s*.045,s*.037,.72,.32);
  ellipse({x:head.x+s*.007,y:head.y-s*.066},s*.079,s*.062,1.05,.94);
  rect({x:head.x-s*.067,y:head.y-s*.025},{x:head.x+s*.008,y:head.y+s*.010},.04,.94,true,true);
  for(const i of [0,1]){
    const arm=p.arms[i],near=i===1;
    capsule(project(arm.shoulder),project(arm.elbow),s*.031,near?1.13:.78,.31);
    const sleeve={x:arm.shoulder.x,y:arm.shoulder.y+(arm.elbow.y-arm.shoulder.y)*.46,z:arm.shoulder.z+(arm.elbow.z-arm.shoulder.z)*.46};
    capsule(project(arm.shoulder),project(sleeve),s*.051,near?1.18:.83,.66);
    capsule(project(arm.elbow),project(arm.hand),s*.024,near?1.07:.77,.32);
    capsule(project(arm.hand),project({...arm.hand,y:arm.hand.y-.080}),s*.020,near?1.09:.79,.35);
    if(near){
      const wrist=project({x:arm.hand.x,y:arm.hand.y+(arm.elbow.y-arm.hand.y)*.12,z:arm.hand.z+(arm.elbow.z-arm.hand.z)*.12});
      ellipse(wrist,s*.028,s*.013,.05,.97,true,true);
    }
  }
  return shapes;
}

export function createField(frame:number,portrait=false):Field{
  return createFieldFromShapes(makeShapes(frame,portrait),frame);
}
export function createFieldFromShapes(shapes:Shape[],frame:number):Field{
  const count=NX*NY,height=new Float32Array(count),tone=new Float32Array(count),body=new Float32Array(count);
  const roles=new Float32Array(count),layers=new Int32Array(count);
  for(const shape of shapes){
    const padX=shape.angle?Math.max(shape.rx,shape.ry,(shape.b.x-shape.a.x)/2,(shape.b.y-shape.a.y)/2):shape.rx;
    const padY=shape.angle?Math.max(shape.rx,shape.ry,(shape.b.x-shape.a.x)/2,(shape.b.y-shape.a.y)/2):shape.ry;
    const minX=Math.max(0,Math.floor((Math.min(shape.a.x,shape.b.x)-padX)/DX)-1),maxX=Math.min(NX-1,Math.ceil((Math.max(shape.a.x,shape.b.x)+padX)/DX)+1);
    const minY=Math.max(0,Math.floor((Math.min(shape.a.y,shape.b.y)-padY)/DY)-1),maxY=Math.min(NY-1,Math.ceil((Math.max(shape.a.y,shape.b.y)+padY)/DY)+1);
    for(let j=minY;j<=maxY;j++)for(let i=minX;i<=maxX;i++){
      let x=i*DX,y=j*DY;let q=2;
      if(shape.clipY!==undefined&&y>shape.clipY)continue;
      if(shape.angle){const cx=(shape.a.x+shape.b.x)/2,cy=(shape.a.y+shape.b.y)/2,xx=x-cx,yy=y-cy,c=Math.cos(shape.angle),s=Math.sin(shape.angle);x=cx+xx*c+yy*s;y=cy-xx*s+yy*c;}
      if(shape.kind==='ellipse')q=((x-shape.a.x)/shape.rx)**2+((y-shape.a.y)/shape.ry)**2;
      else if(shape.kind==='capsule'){
        const ax=shape.b.x-shape.a.x,ay=shape.b.y-shape.a.y;
        const t=clamp(((x-shape.a.x)*ax+(y-shape.a.y)*ay)/(ax*ax+ay*ay||1));
        q=((x-shape.a.x-t*ax)**2+(y-shape.a.y-t*ay)**2)/(shape.rx*shape.rx);
      }else if(shape.kind==='poly'){
        let inside=false,edge=1e9;const pts=shape.points!;
        for(let k=0,l=pts.length-1;k<pts.length;l=k++){
          const a=pts[k],b=pts[l],ax=b.x-a.x,ay=b.y-a.y;
          if(((a.y>y)!==(b.y>y))&&(x<(b.x-a.x)*(y-a.y)/(b.y-a.y)+a.x))inside=!inside;
          const t=clamp(((x-a.x)*ax+(y-a.y)*ay)/(ax*ax+ay*ay||1));
          edge=Math.min(edge,Math.hypot(x-a.x-t*ax,y-a.y-t*ay));
        }
        q=inside?(1-clamp(edge/14))**2:2;
      }else{
        const cx=(shape.a.x+shape.b.x)/2,cy=(shape.a.y+shape.b.y)/2;
        q=Math.max(Math.abs((x-cx)/((shape.b.x-shape.a.x)/2)),Math.abs((y-cy)/((shape.b.y-shape.a.y)/2)))**6;
      }
      if(q>=1)continue;
      const at=j*NX+i,cover=smooth((1-q)/.10),h=shape.depth*(1-q)**1.15;
      const layer=Math.round((shape.layer??0)*1000);
      if(layer<layers[at]&&cover>.15)continue;
      if(layer>layers[at]&&cover>.15){height[at]=0;tone[at]=0;body[at]=0;layers[at]=layer;}
      if(shape.detail){height[at]+=h;tone[at]=Math.max(tone[at],shape.tone*cover);roles[at]=shape.role??(shape.body?1:0);}
      else if(h>height[at]){height[at]=h;tone[at]=shape.tone;roles[at]=shape.role??(shape.body?1:0);}
      body[at]=Math.max(body[at],cover*(shape.body?1:.20));
    }
  }
  // Smooth the volume only; the image remains strokes, never a shaded raster fill.
  const blur=new Float32Array(count),kernel=[1,2,3,2,1];
  for(let j=0;j<NY;j++)for(let i=0;i<NX;i++){
    let sum=0;for(let k=-2;k<=2;k++)sum+=height[j*NX+clamp(i+k,0,NX-1)]*kernel[k+2];blur[j*NX+i]=sum/9;
  }
  for(let j=0;j<NY;j++)for(let i=0;i<NX;i++){
    let sum=0;for(let k=-2;k<=2;k++)sum+=blur[clamp(j+k,0,NY-1)*NX+i]*kernel[k+2];height[j*NX+i]=sum/9;
  }
  const dark=new Float32Array(count),flow=new Float32Array(count),coverage=new Float32Array(count),role=new Float32Array(count);
  for(let i=0;i<NX;i++){
    for(let j=0;j<NY;j++){
      const at=j*NX+i,left=height[j*NX+Math.max(0,i-1)],right=height[j*NX+Math.min(NX-1,i+1)];
      const top=height[Math.max(0,j-1)*NX+i],bottom=height[Math.min(NY-1,j+1)*NX+i];
      const gx=(right-left)*12,gy=(bottom-top)*12;
      dark[at]=body[at]*clamp(tone[at]+gx*.12-gy*.08,.1,.98);
    }
    // Redistribute ONE continuous family by a positive density integral. No line
    // starts/ends at a body silhouette; dark areas borrow spacing from light areas.
    const mapped=Float32Array.from({length:NY},(_,j)=>j*DY);
    const intervals:number[][]=[];
    for(let j=0;j<NY;j++){
      if(body[j*NX+i]<=.22)continue;
      const begin=j;while(j<NY-1&&body[(j+1)*NX+i]>.22)j++;
      const lo=Math.max(0,begin-14),hi=Math.min(NY-1,j+14),last=intervals.at(-1);
      if(last&&lo<=last[1])last[1]=hi;else intervals.push([lo,hi]);
    }
    for(const [lo,hi] of intervals){
      const cumulative=new Float32Array(NY);
      for(let j=lo+1;j<=hi;j++){
        const at=j*NX+i,density=1+(body[at]>.22?dark[at]*1.2:0);
        cumulative[j]=cumulative[j-1]+density*DY;
      }
      const total=cumulative[hi];let actual=lo+1;
      for(let label=lo;label<=hi;label++){
        const level=(label-lo)/(hi-lo)*total;
        while(actual<hi&&cumulative[actual]<level)actual++;
        const fraction=clamp((level-cumulative[actual-1])/(cumulative[actual]-cumulative[actual-1]));
        mapped[label]=(actual-1+fraction)*DY;
      }
    }
    let previous=-100;
    for(let label=0;label<NY;label++){
      const y=mapped[label];
      const h=fieldSample(height,i,y),occupancy=fieldSample(body,i,y);
      const rhythm=occupancy*h*Math.sin(frame/30*2.1+i*.04-y*.02)*.85;
      const wanted=y-h*22+rhythm;
      flow[label*NX+i]=Math.max(previous+DY*.32,wanted);previous=flow[label*NX+i];
      coverage[label*NX+i]=occupancy;
      role[label*NX+i]=roles[Math.round(clamp(y/DY,0,NY-1))*NX+i];
    }
  }
  return {height,dark,body,flow,coverage,role};
}
export function fieldSample(data:Float32Array,xIndex:number,y:number){
  const j=clamp(y/DY,0,NY-1),a=Math.floor(j),b=Math.min(NY-1,a+1),f=j-a;
  return data[a*NX+xIndex]*(1-f)+data[b*NX+xIndex]*f;
}
