import React from 'react';
import {gaitPose,type V} from '../spatial/gait';
export const GaitCheck:React.FC=()=> <svg viewBox="0 0 1920 1080" width="1920" height="1080" style={{background:'#eee9dc'}}>
  <g fontFamily="sans-serif" fill="#273943"><text x="70" y="85" fontSize="35">侧面关节方向检查 · 面向左侧行走</text><text x="70" y="138" fontSize="24">膝盖向身体前方弯折；手肘向后方弯折。旧版肘部同向错误已修正。</text></g>
  {[.06,.28,.50].map((t,index)=>{
    const pose=gaitPose(t,.95),x=360+index*600,scale=340;
    const p=(v:V)=>({x:x-v.z*scale+v.x*scale*.22,y:930-v.y*scale});
    const joint=(v:V,color:string)=>{const q=p(v);return <circle cx={q.x} cy={q.y} r="7" fill={color}/>;};
    const chain=(points:V[],color:string)=><><polyline points={points.map(p).map(q=>`${q.x},${q.y}`).join(' ')} fill="none" stroke={color} strokeWidth="8"/>{points.map((v,i)=><g key={i}>{joint(v,color)}</g>)}</>;
    return <g key={index}>
      <path d={`M${x-230} 930H${x+230}`} stroke="#9da6a0" strokeWidth="3"/>
      {pose.legs.map((l,i)=><g key={i}>{chain([l.hip,l.knee,l.ankle],i?'#2c5967':'#85989b')}</g>)}
      {pose.arms.map((a,i)=><g key={i}>{chain([a.shoulder,a.elbow,a.hand],i?'#986955':'#c2a08c')}</g>)}
      <path d={`M${x} ${930-pose.pelvis*scale}V${930-(pose.pelvis+.63)*scale}`} stroke="#475b60" strokeWidth="13"/>
      <ellipse cx={x} cy={930-(pose.pelvis+.80)*scale} rx="25" ry="39" fill="none" stroke="#475b60" strokeWidth="5"/>
      <text x={x-115} y="1000" fontFamily="sans-serif" fontSize="25" fill="#273943">步态相位 {t.toFixed(2)}秒</text>
      <path d={`M${x-130} 255H${x-225}L${x-205} 244M${x-225} 255L${x-205} 266`} stroke="#475b60" fill="none" strokeWidth="4"/>
      <text x={x-220} y="232" fontFamily="sans-serif" fontSize="20">前方</text>
    </g>;
  })}
</svg>;
