import {clamp,mix,smooth,REJECT_FRAME} from '../timeline';
import type {Shape,P} from '../parallel/field';
import type {Mark} from './geometry';
import type {Camera} from '../projection';
export type PhoneUI={center:P;width:number;height:number;angle:number;state:'music'|'incoming'|'declined';visible:number};
export function povCamera(frame:number):Camera{
  const down=smooth((frame-720)/45),chest=smooth((frame-1260)/85),pitch=mix(.09,.56,down)+chest*.18;
  const breath=frame>=1260?Math.sin((frame-1260)/30*Math.PI*.8)*.0025*smooth((frame-1260)/24):0;
  const distance=350;
  return {target:[-435,486-Math.cos(pitch)*distance,137-Math.sin(pitch)*distance+breath*100],yaw:0,pitch: pitch+breath,distance};
}
export function povForeground(frame:number,shapes:Shape[],marks:Mark[]):PhoneUI{
  const down=smooth((frame-720)/45),draw=smooth((frame-746)/75),chest=smooth((frame-1260)/85);
  const breath=frame>=1260?Math.sin((frame-1260)/30*Math.PI*.8)*2.5*smooth((frame-1260)/24):0;
  const dy=mix(530,0,down)-chest*75+breath;
  const P=(x:number,y:number)=>({x,y:y+dy});
  const ell=(x:number,y:number,rx:number,ry:number,depth:number,tone:number,layer=210,role=1)=>shapes.push({kind:'ellipse',a:P(x,y),b:P(x,y),rx,ry,depth,tone,body:true,role,layer});
  const cap=(x:number,y:number,xx:number,yy:number,r:number,depth:number,tone:number,layer=210,role=1)=>shapes.push({kind:'capsule',a:P(x,y),b:P(xx,yy),rx:r,ry:r,depth,tone,body:true,role,layer});
  const line=(pts:number[][],width=2.5,role=1,alpha=.85)=>marks.push({points:pts.map(([x,y])=>P(x,y)),role,width,alpha});
  // Knees and shoes occupy the lower middle of the seated point of view.
  cap(620,1250,705,865,104,1.05,.76);ell(705,860,103,116,1.10,.73);
  cap(1280,1250,1195,865,104,1.05,.76);ell(1195,860,103,116,1.10,.73);
  cap(735,822,775,694,54,.80,.78);cap(1167,822,1130,694,54,.80,.78);
  ell(777,690,63,34,.66,.65);ell(1125,690,63,34,.66,.65);
  line([[655,1060],[680,952],[718,888]],2);line([[1242,1060],[1222,955],[1187,886]],2);
  const phoneX=mix(660,865,draw),phoneY=mix(1100,577,draw)+chest*70;
  const vibration=frame>=840&&frame<REJECT_FRAME?Math.sin(frame*.58)*1.15:0;
  const ui:PhoneUI={center:P(phoneX+vibration,phoneY),width:226,height:402,angle:-.115,state:frame<840?'music':frame<REJECT_FRAME?'incoming':'declined',visible:draw};
  const wrist={x:phoneX-169,y:phoneY+204};
  // Left sleeve, forearm and wrist. The watch stays on the same wrist.
  cap(250,1270,485,1070,84,1.1,.70,211);
  cap(485,1070,wrist.x,wrist.y,40,1.05,.34,212);
  cap(wrist.x,wrist.y,phoneX-103,phoneY+95,27,1.08,.34,213);
  ell(wrist.x-8,wrist.y+14,43,27,.10,.96,213.1);
  line([[wrist.x-39,wrist.y+2],[wrist.x+24,wrist.y-12],[wrist.x+37,wrist.y+25],[wrist.x-24,wrist.y+40],[wrist.x-39,wrist.y+2]],3.4);
  // Four far fingers remain behind the handset, the thumb rests on its edge.
  for(let j=0;j<4;j++)cap(phoneX+92,phoneY+46+j*27,phoneX+122,phoneY+35+j*27,10,.14,.35,213.2);
  const c=ui.center,w=ui.width,h=ui.height;
  shapes.push({kind:'rect',a:{x:c.x-w/2,y:c.y-h/2},b:{x:c.x+w/2,y:c.y+h/2},rx:0,ry:0,depth:.50,tone:.86,body:true,role:4,layer:214,angle:ui.angle,feature:'hero-phone'});
  cap(phoneX-95,phoneY+112,phoneX-66,phoneY+64,16,.12,.36,215);
  line([[phoneX-94,phoneY+111],[phoneX-78,phoneY+85],[phoneX-66,phoneY+65]],2.5);
  for(let j=0;j<4;j++)line([[phoneX+108,phoneY+45+j*27],[phoneX+120,phoneY+41+j*27]],2.2);
  // Right index approaches the actual transformed decline-button center.
  const approach=smooth((frame-948)/(REJECT_FRAME-948)),retreat=smooth((frame-REJECT_FRAME-8)/60);
  const buttonY=h*.285,button={x:phoneX-Math.sin(ui.angle)*buttonY,y:phoneY+Math.cos(ui.angle)*buttonY};
  const tremor=1.2*Math.sin(frame*.71)*clamp(approach-retreat);
  const tx=mix(mix(1460,button.x,approach),1460,retreat)-chest*360+tremor;
  const ty=mix(mix(1235,button.y,approach),1080,retreat)-chest*230;
  if(chest>.01){
    ell(960,1450-chest*260,770,345,1.13,.72,216);
    for(let j=0;j<3;j++)line([[560+j*150,1230-chest*100],[680+j*105,1150-chest*110],[810+j*65,1130-chest*95]],2.4);
  }
  cap(1660,1370,tx+230,ty+235,74,1.13,.69,217);
  cap(tx+230,ty+235,tx+132,ty+125,46,1.05,.34,218);
  ell(tx+101,ty+101,58,67,1.07,.36,219);
  cap(tx+111,ty+98,tx,ty,13,1.08,.32,220);
  for(let j=0;j<3;j++)cap(tx+119+j*20,ty+86+j*14,tx+143+j*15,ty+132+j*9,12,1,.35,219.2);
  line([[tx+9,ty+11],[tx+26,ty+25]],2.2);line([[tx+49,ty+49],[tx+63,ty+58]],2.2);
  line([[tx+100,ty+72],[tx+111,ty+88],[tx+103,ty+107]],2.2);
  return ui;
}
