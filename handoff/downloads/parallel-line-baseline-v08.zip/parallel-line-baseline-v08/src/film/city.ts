import type {Camera,V3} from '../projection';
import type {Shape} from '../parallel/field';
import {geometry,type Mark} from './geometry';
import {clamp,rand} from '../timeline';
export function cityGeometry(frame:number,camera:Camera,shapes:Shape[],marks:Mark[]){
  const {poly,capsule,ellipse,line,p}=geometry(camera,shapes,marks);
  const plane=(x:number,y:number,w:number,h:number,z=0):V3[]=>[[x,y,z],[x+w,y,z],[x+w,y+h,z],[x,y+h,z]];
  // Ground is below all standing objects. The depth of one arbitrary polygon
  // anchor cannot describe a large ground plane and used to erase lower limbs.
  poly(plane(-3600,-3600,7200,7200),.025,.08,0,[0,0,-20],1);
  poly(plane(-290,-3600,580,7200,.2),.06,.19,11,[0,0,-15],2);
  poly(plane(-3600,-280,7200,560,.3),.06,.19,11,[0,0,-14],3);
  // Sidewalk edges, crosswalks and central lane dashes anchor the intersection.
  for(const sign of [-1,1]){
    for(let i=0;i<18;i++){
      poly(plane(-275+i*31,sign===1?280:-420,17,140,1.2),.11,.14,12,[-10,sign*350,1],4);
      poly(plane(sign===1?320:-380,-270+i*30,70,16,1.1),.10,.14,12,[sign*350,0,1],4);
    }
    for(let i=-8;i<=8;i++){
      line([[i*180,sign*22,1],[i*180+84,sign*22,1]],12,2,.45);
      line([[sign*22,i*180,1],[sign*22,i*180+84,1]],12,2,.45);
    }
    line([[-3500,sign*285,1],[3500,sign*285,1]],5,3,.55);
    line([[sign*295,-3500,1],[sign*295,3500,1]],5,3,.55);
  }
  for(const sx of [-1,1])for(const sy of [-1,1])for(let i=0;i<2;i++){
    const x=sx===1?435+i*360:-845-i*360,y=sy===1?690:-1210,w=285,h=480,z=260+rand(i+sx*19+sy*23)*230;
    poly([[x,y,0],[x+w,y,0],[x+w,y,z],[x,y,z]],.44,.30,5,[x+w/2,y,z/2]);
    poly([[x+w,y,0],[x+w,y+h,0],[x+w,y+h,z],[x+w,y,z]],.36,.23,5,[x+w,y+h/2,z/2]);
    poly(plane(x,y,w,h,z),.23,.18,12,[x+w/2,y+h/2,z]);
    // Sparse floor/window cues; the continuous line field supplies the texture.
    for(let j=1;j<=6;j++){
      const zz=z*j/7;line([[x,y,zz],[x+w,y,zz],[x+w,y+h,zz]],5,1.8,.35);
    }
    for(let j=1;j<=3;j++)line([[x+w*j/4,y,8],[x+w*j/4,y,z]],5,1.6,.32);
  }
  for(const [i,x,y] of [[0,-650,520],[1,490,490],[2,-470,-480],[3,490,-490],[4,-840,580],[5,790,560]]){
    capsule([x,y,0],[x,y,150],5,.25,.35,6);
    const wind=Math.sin(frame/30*1.2+i)*2.5;
    for(let j=0;j<4;j++)ellipse([x+Math.cos(j*2)*35+wind,y+Math.sin(j*2)*26,172+(j%2)*24],53,47,.48,.42,6);
  }
  // Bench sits in the southwest corner, aligned east/west and facing north.
  for(const y of [474,486,498]){capsule([-512,y,53],[-358,y,53],3.8,.50,.52,15,.03);line([[-512,y,53],[-358,y,53]],15,3.2,.9);}
  for(const z of [84,99]){capsule([-512,509,z],[-358,509,z],3.7,.52,.50,15);line([[-512,509,z],[-358,509,z]],15,3.6,.9);}
  for(const x of [-500,-370]){
    capsule([x,482,0],[x,482,52],2.5,.35,.60,15);
    capsule([x,509,0],[x,509,103],2.4,.35,.60,15);
    line([[x,482,0],[x,482,52]],15,3,.85);line([[x,509,0],[x,509,103]],15,3,.85);
  }
  // Four traffic poles share the global state. The hero's bench-side pole is fixed.
  for(const sx of [-1,1])for(const sy of [-1,1]){
    const x=sx*343,y=sy*438;
    capsule([x,y,0],[x,y,210],3.2,.3,.4,5);
    capsule([x,y,209],[x-sx*40,y,209],3.2,.3,.4,5);
    capsule([x-sx*40,y,188],[x-sx*40,y,220],8,.40,.66,5);
    ellipse([x-sx*40,y-2,frame<55?211:195],4.8,4.8,.08,.55,frame<55?8:9,.02);
  }
  // East/west traffic runs beyond the southern pedestrian lane. No cars cross it.
  for(let i=0;i<14;i++){
    const sign=i%2?1:-1,t=Math.max(0,(frame-55)/30),x=(sign>0?-2300:2300)+sign*((i>>1)*370+t*135),y=sign*110;
    if(Math.abs(x)>3600)continue;
    const w=102,h=42,z=31;
    poly(plane(x,y,w,h,z),.32,.43,i%3?7:12,[x+w/2,y+h/2,z]);
    poly([[x,y,0],[x+w,y,0],[x+w,y,z],[x,y,z]],.30,.47,7,[x+w/2,y,18]);
    poly(plane(x+24,y+4,46,h-8,51),.27,.58,5,[x+47,y+21,51]);
    if(camera.pitch<.5)for(const dx of [20,80])ellipse([x+dx,y-1,8],8,8,.20,.72,5,.03);
  }
}
