import type {Shape} from '../parallel/field';
import {clamp} from '../timeline';
import {gaitPose} from '../spatial/gait';
import {filmCamera,heroAt,heroPose,crowdAt} from './model';
import {actorGeometry} from './actor';
import {cityGeometry} from './city';
import type {Mark} from './geometry';
import {povCamera,povForeground,type PhoneUI} from './pov';
export const FILM_PALETTE:Record<number,string>={0:'#89978f',1:'#355d6b',2:'#827466',3:'#718375',4:'#2b4652',5:'#748784',6:'#6e8674',7:'#857e70',8:'#9b635e',9:'#6f937d',10:'#817b86',11:'#86918f',12:'#a5aea0',13:'#8a978b',14:'#969285',15:'#657d74'};
export function filmScene(inputFrame:number){
  const frame=clamp(inputFrame,0,1380),shapes:Shape[]=[],marks:Mark[]=[];
  const camera=frame<720?filmCamera(frame):povCamera(frame);
  cityGeometry(frame,camera,shapes,marks);
  for(const person of crowdAt(frame)){
    actorGeometry(camera,shapes,marks,{...person,role:frame>=720?(person.id%2?13:14):person.role,root:person,pose:gaitPose(frame/30+person.phase,person.speed),frame,legsOnly:frame>=720});
  }
  let phone:PhoneUI|undefined;
  if(frame<720)actorGeometry(camera,shapes,marks,{root:heroAt(frame),heading:heroAt(frame).heading,pose:heroPose(frame),scale:1,role:1,hero:true,frame});
  else phone=povForeground(frame,shapes,marks);
  return {shapes,marks,phone,camera,frame};
}
