import {gaitPose,twoBone,THIGH,SHIN,type V} from '../spatial/gait';
import {clamp,mix,smooth} from '../timeline';
import {phoneAction} from '../detail/action';
import type {Camera,V3} from '../projection';
export type Pose=ReturnType<typeof gaitPose>;
export const BENCH={x:-435,y:486};
export function heroAt(frame:number){
  if(frame<300)return {x:350,y:350,heading:[-1,0] as [number,number]};
  if(frame<480)return {x:mix(350,-345,(frame-300)/179),y:350,heading:[-1,0] as [number,number]};
  const t=(frame-480)/239,walk=smooth((frame-480)/140);
  const distance=Math.hypot(BENCH.x+345,BENCH.y-350),turn=smooth((frame-620)/45);
  return {x:mix(-345,BENCH.x,walk),y:mix(350,BENCH.y,walk),heading:[mix((BENCH.x+345)/distance,0,turn),mix((BENCH.y-350)/distance,-1,turn)] as [number,number]};
}
export function seatedPose(amount=1):Pose{
  const p=gaitPose(0,.65);p.pelvis=mix(.94,.61,amount);
  for(const i of [0,1]){
    const x=i? .095:-.095,hip={x,y:p.pelvis,z:-.025*amount},ankle={x,y:.065,z:mix(i?.15:-.12,.55,amount)};
    p.legs[i]={...p.legs[i],hip,ankle,knee:twoBone(hip,ankle,THIGH,SHIN),stance:true};
  }
  for(const i of [0,1]){
    const x=i?.215:-.215,shoulder={x,y:p.pelvis+.55,z:-.07*amount},hand={x,y:p.pelvis+.08,z:.25*amount};
    p.arms[i]={shoulder,hand,elbow:twoBone(shoulder,hand,.29,.28,-1)};
  }return p;
}
export function heroPose(frame:number):Pose{
  if(frame<300)return gaitPose(0,.65);
  if(frame<480){
    const p=gaitPose((frame-300)/30*(695/179*30/100/.95),.95),action=phoneAction(clamp((frame-320)/.77,0,179));
    if(frame>320&&frame<459){
      const dy=p.pelvis-.93;
      p.arms[1]=Object.fromEntries(Object.entries(action.pose.arms[1]).map(([k,v])=>[k,{...v,y:v.y+dy}])) as Pose['arms'][number];
    }return p;
  }
  const at=heroAt(Math.min(frame,620)),distance=Math.hypot(at.x+345,at.y-350);
  const standing=gaitPose(distance/65,.65);
  if(frame<620)return standing;
  const weight=smooth((frame-620)/75),seat=seatedPose(1),p=standing;
  p.pelvis=mix(p.pelvis,seat.pelvis,weight);
  const lerp=(a:V,b:V):V=>({x:mix(a.x,b.x,weight),y:mix(a.y,b.y,weight),z:mix(a.z,b.z,weight)});
  for(const i of [0,1]){
    const hip=lerp(p.legs[i].hip,seat.legs[i].hip),ankle=lerp(p.legs[i].ankle,seat.legs[i].ankle);
    p.legs[i]={...p.legs[i],hip,ankle,knee:twoBone(hip,ankle,THIGH,SHIN)};
    const shoulder=lerp(p.arms[i].shoulder,seat.arms[i].shoulder),hand=lerp(p.arms[i].hand,seat.arms[i].hand);
    p.arms[i]={shoulder,hand,elbow:twoBone(shoulder,hand,.29,.28,-1)};
  }return p;
}
export function heroGaze(frame:number){return frame>=320&&frame<459?phoneAction((frame-320)/.77).gaze:0;}
export type Walker={id:number;x:number;y:number;heading:[number,number];speed:number;phase:number;scale:number;role:number;bag:boolean;elder:boolean};
export function crowdAt(frame:number):Walker[]{
  const t=frame/30;
  // Each lane has a finite queue, no modulo wrap, sudden identity changes or
  // random spawn. The empty central lane gives the protagonist breathing room.
  return Array.from({length:30},(_,i)=>{
    const lane=i%5,row=Math.floor(i/5),direction=lane%2?1:-1;
    const initial=direction===-1?1050+row*225:-1100-row*235;
    const speed=53+(i%4)*4;
    return {id:i,x:initial+direction*speed*t,y:[255,292,409,446,-350][lane],heading:[direction,0],speed:speed/100,
      phase:i*.31,scale:.88+(i%5)*.025,role:i%3===0?2:i%3===1?3:10,bag:i%4===0,elder:i%9===0};
  });
}
export function filmCamera(frame:number):Camera{
  const hero=heroAt(frame);
  if(frame<300){
    const t=smooth(frame/240),close=smooth((frame-225)/74);
    return {target:[mix(0,350,t),mix(0,350,t),mix(0,145,t)],yaw:mix(0,-Math.PI/2,t),pitch:mix(Math.PI/2,.035,t),distance:mix(mix(2400,540,t),230,close)};
  }
  if(frame<480)return {target:[hero.x-15,350,117],yaw:Math.PI/2,pitch:.025,distance:mix(350,275,smooth((frame-300)/179))};
  const t=smooth((frame-480)/160);
  return {target:[mix(hero.x,-435,t),mix(hero.y,486,t),mix(115,95,t)],yaw:-.65,pitch:.045,distance:mix(460,270,smooth((frame-565)/145))};
}
export function localToWorld(root:{x:number;y:number},heading:[number,number],v:V,scale=1):V3{
  const len=Math.hypot(...heading)||1,dx=heading[0]/len,dy=heading[1]/len;
  return [root.x+(v.z*dx+v.x*dy)*100*scale,root.y+(v.z*dy-v.x*dx)*100*scale,v.y*100*scale];
}
