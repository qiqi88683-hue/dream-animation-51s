import {clamp,smooth} from '../timeline';
export function endingAt(frame:number){
  const progress=clamp((frame-1380)/149),local=Math.max(0,frame-1380);
  const envelope=smooth(progress/.22)*(1-smooth((progress-.78)/.22));
  return {progress,local,fade:smooth(progress),strength:envelope*(.35+.65*smooth(progress/.65)),
    shakeX:envelope*2.4*(Math.sin(local*.63)+.28*Math.sin(local*1.13)),
    shakeY:envelope*1.4*Math.sin(local*.79),roll:envelope*.0012*Math.sin(local*.51)};
}
const buffers=new WeakMap<CanvasRenderingContext2D,HTMLCanvasElement>();
export function signalEnding(ctx:CanvasRenderingContext2D,frame:number){
  const e=endingAt(frame);if(e.strength===0)return;
  const W=ctx.canvas.width,H=ctx.canvas.height;
  let buffer=buffers.get(ctx);
  if(!buffer){buffer=document.createElement('canvas');buffer.width=W;buffer.height=H;buffers.set(ctx,buffer);}
  const copy=buffer.getContext('2d')!;copy.clearRect(0,0,W,H);copy.drawImage(ctx.canvas,0,0);
  ctx.fillStyle='#c8d0ca';ctx.fillRect(0,0,W,H);ctx.save();
  ctx.translate(W/2+e.shakeX,H/2+e.shakeY);ctx.rotate(e.roll);ctx.scale(1+.024*e.strength,1+.024*e.strength);ctx.translate(-W/2,-H/2);
  const scan=140+(e.local*10.5)%800;
  for(let y=0;y<H;y+=6){
    const band=Math.exp(-(((y-scan)/26)**2));
    const dx=e.strength*(5*Math.sin(y*.024+e.local*.45)+3*Math.sin(y*.071-e.local*.27)+13*band*Math.sin(e.local*.57));
    const dy=e.strength*2.8*Math.sin(y*.085+e.local*.31);
    ctx.drawImage(buffer,0,y,W,Math.min(6,H-y),dx,y+dy,W,Math.min(6,H-y));
  }
  ctx.globalAlpha=.12*e.strength;ctx.strokeStyle='#355d6b';ctx.lineWidth=2.7;
  for(let row=0;row<9;row++){
    const yy=160+row*96;ctx.beginPath();
    for(let x=0;x<=W;x+=16){
      const y=yy+e.strength*(10*Math.sin(x*.031+row+e.local*.15)+5*Math.sin(x*.079-row*.7));
      if(x===0)ctx.moveTo(x,y);else ctx.lineTo(x,y);
    }ctx.stroke();
  }
  ctx.restore();ctx.globalAlpha=1;
}
