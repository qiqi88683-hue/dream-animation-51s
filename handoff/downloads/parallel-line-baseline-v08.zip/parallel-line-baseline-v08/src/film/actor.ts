import type {Camera,V3} from '../projection';
import {makeProject} from '../projection';
import type {Shape,P} from '../parallel/field';
import {localToWorld,heroGaze,type Pose} from './model';
import type {Mark} from './geometry';
import {phoneAction} from '../detail/action';
export type ActorOptions={root:{x:number;y:number};heading:[number,number];pose:Pose;scale:number;role:number;hero?:boolean;frame:number;bag?:boolean;elder?:boolean;legsOnly?:boolean};
export function actorGeometry(camera:Camera,shapes:Shape[],marks:Mark[],o:ActorOptions){
  const project=makeProject(camera).project,world=(v:{x:number;y:number;z:number})=>localToWorld(o.root,o.heading,v,o.scale),p=(v:{x:number;y:number;z:number})=>project(world(v));
  const base=project([o.root.x,o.root.y,85*o.scale]);if(base.depth<80||base.x<-500||base.x>2420)return;
  const s=base.scale*100*o.scale,layer=200-base.depth*.01,role=o.role,pose=o.pose;
  const ell=(a:P,rx:number,ry:number,depth:number,tone:number,extra:Partial<Shape>={})=>shapes.push({kind:'ellipse',a,b:a,rx:Math.max(1.5,rx),ry:Math.max(1.5,ry),depth,tone,body:true,role,layer,...extra});
  const cap=(a:P,b:P,r:number,depth:number,tone:number,extra:Partial<Shape>={})=>shapes.push({kind:'capsule',a,b,rx:Math.max(1,r),ry:Math.max(1,r),depth,tone,body:true,role,layer,...extra});
  const mark=(points:P[],width=2.3,alpha=.8)=>marks.push({points,role,width,alpha});
  const gaze=o.hero?heroGaze(o.frame):0;
  for(const i of [0,1]){
    const a=pose.legs[i];
    if(!o.legsOnly)cap(p(a.hip),p(a.knee),s*.054,.93,.75);
    cap(p(a.knee),p(a.ankle),s*.040,o.legsOnly?.35:.88,o.legsOnly?.27:.78);
    cap(p({...a.ankle,y:.035,z:a.ankle.z-.025}),p({...a.ankle,y:.035,z:a.ankle.z+.12}),s*.030,.60,.65);
  }
  if(o.legsOnly)return;
  const c={x:0,y:pose.pelvis+.285,z:o.elder?.07:-.015};
  const side=p({...c,x:.16}),side2=p({...c,x:-.16}),front=p({...c,z:c.z+.14}),back=p({...c,z:c.z-.14});
  const rx=Math.max(s*.12,Math.hypot((side.x-side2.x)/2,(front.x-back.x)/2));
  ell(p(c),rx,s*.32*Math.max(.20,Math.cos(camera.pitch)),1.14,.70);
  cap(p({x:0,y:pose.pelvis+.57,z:0}),p({x:0,y:pose.pelvis+.67,z:gaze*.035}),s*.035,.90,.40);
  const hc={x:0,y:pose.pelvis+.78-gaze*.012,z:.012+gaze*.04},head=p(hc),frontHead=p({...hc,z:hc.z+.075}),rearHead=p({...hc,z:hc.z-.075});
  const headRY=s*(.118*Math.cos(camera.pitch)+.073*Math.sin(camera.pitch));
  ell(head,s*.075,headRY,.96,.38);
  // Profile projection comes from the same local facial landmarks in every view.
  ell(p({...hc,y:hc.y+.002,z:hc.z+.078}),s*.020,s*.020,.70,.34);
  ell(p({...hc,y:hc.y+.065,z:hc.z-.008}),s*.079,s*.061,1.05,.91);
  if(o.hero&&camera.pitch<.8){
    const left=p({...hc,x:.08,y:hc.y+.013,z:hc.z+.069}),right=p({...hc,x:-.08,y:hc.y+.013,z:hc.z+.069});
    cap(left,right,s*.005,.04,.95,{detail:true});
    mark([left,{x:left.x,y:left.y+s*.026},{x:right.x,y:right.y+s*.026},right,left],Math.max(1.5,s*.004));
    const collar=p({x:0,y:pose.pelvis+.56,z:.025});mark([{x:collar.x-rx*.5,y:collar.y-s*.012},collar,{x:collar.x+rx*.5,y:collar.y-s*.012}],2,.65);
    ell(p({...hc,x:.078,y:hc.y-.025,z:hc.z-.010}),s*.014,s*.022,.04,.7,{detail:true,feature:'earphone'});
  }
  // Projected camera depth chooses the genuinely nearer arm, including reverse
  // and front views, instead of assuming that screen-left is anatomical left.
  const armOrder=[0,1].sort((a,b)=>p(pose.arms[b].shoulder).depth-p(pose.arms[a].shoulder).depth);
  for(const i of armOrder){
    const arm=pose.arms[i],near=i===armOrder[1],armLayer=layer+(near?.2:-.05),a=p(arm.shoulder),e=p(arm.elbow),h=p(arm.hand);
    cap(a,e,s*.031,1.13,.33,{layer:armLayer});
    const sleeve={x:arm.shoulder.x,y:arm.shoulder.y+(arm.elbow.y-arm.shoulder.y)*.46,z:arm.shoulder.z+(arm.elbow.z-arm.shoulder.z)*.46};
    cap(a,p(sleeve),s*.051,1.18,.66,{layer:armLayer});cap(e,h,s*.024,1.07,.34,{layer:armLayer});
    cap(h,p({...arm.hand,y:arm.hand.y-.072}),s*.020,1.09,.35,{layer:armLayer});
    if(o.hero&&i===1){
      const watch=p({x:arm.hand.x,y:arm.hand.y+(arm.elbow.y-arm.hand.y)*.12,z:arm.hand.z+(arm.elbow.z-arm.hand.z)*.12});
      ell(watch,s*.028,s*.014,.05,.97,{detail:true,layer:armLayer+.02,feature:'left-watch'});
      mark([{x:watch.x-s*.025,y:watch.y-s*.008},{x:watch.x+s*.024,y:watch.y-s*.009}],2.5);
    }
  }
  if(o.bag){
    const arm=pose.arms[0],a=p({...arm.hand,y:arm.hand.y-.15});ell(a,s*.075,s*.09,.66,.60,{layer:layer+.3});
    mark([p(arm.hand),{x:a.x-s*.04,y:a.y-s*.08},{x:a.x+s*.04,y:a.y-s*.08},p(arm.hand)],1.8,.6);
  }
  if(o.hero&&o.frame>=320&&o.frame<459){
    // Same persistent phone as the seated POV; mostly hidden until it clears
    // the left pocket. Its dimensions do not change during the action.
    const action=phoneAction((o.frame-320)/.77);
    if(action.phone.exposed>0){
      const phone=p({...action.phone.center,y:action.phone.center.y+pose.pelvis-.93}),w=s*.074,h=s*.155,clipY=p({x:.215,y:.975+pose.pelvis-.93,z:.055}).y;
      shapes.push({kind:'rect',a:{x:phone.x-w/2,y:phone.y-h/2},b:{x:phone.x+w/2,y:phone.y+h/2},rx:0,ry:0,body:true,role:4,layer:layer+.12,depth:.5,tone:.86,clipY});
      marks.push({points:[{x:phone.x-w/2,y:phone.y-h/2},{x:phone.x+w/2,y:phone.y-h/2},{x:phone.x+w/2,y:phone.y+h/2},{x:phone.x-w/2,y:phone.y+h/2},{x:phone.x-w/2,y:phone.y-h/2}],role:4,width:2.2,clipY});
    }
  }
}
