import {makeProject,type Camera,type V3} from '../projection';
import {clamp} from '../timeline';
import type {P,Shape} from '../parallel/field';
export type Mark={points:P[];role:number;width:number;alpha?:number;clipY?:number};
export function geometry(camera:Camera,shapes:Shape[],marks:Mark[]){
  const {project:p}=makeProject(camera);
  const layer=(at:V3)=>200-p(at).depth*.01;
  const poly=(vertices:V3[],relief:number,tone:number,role:number,at?:V3,layerOverride?:number)=>{
    let pts=vertices;
    // Clip to a near plane before perspective projection. Large road polygons
    // otherwise disappear when one corner moves behind the descending camera.
    const clipped:V3[]=[];
    for(let i=0;i<pts.length;i++){
      const a=pts[i],b=pts[(i+1)%pts.length],da=p(a).depth,db=p(b).depth;
      if(da>=45)clipped.push(a);
      if((da>=45)!==(db>=45)){const t=(45-da)/(db-da);clipped.push(a.map((v,k)=>v+(b[k]-v)*t) as V3);}
    }
    if(clipped.length<3)return;
    const q=clipped.map(p),xs=q.map(v=>v.x),ys=q.map(v=>v.y);
    if(Math.max(...xs)<0||Math.min(...xs)>1920||Math.max(...ys)<0||Math.min(...ys)>1080)return;
    const center=at??vertices[0];
    shapes.push({kind:'poly',a:{x:Math.min(...xs),y:Math.min(...ys)},b:{x:Math.max(...xs),y:Math.max(...ys)},rx:0,ry:0,points:q,depth:relief,tone,body:role!==0,role,layer:layerOverride??layer(center)});
  };
  const capsule=(a:V3,b:V3,r:number,relief:number,tone:number,role:number,offset=0)=>{
    const aa=p(a),bb=p(b);if(aa.depth<45||bb.depth<45)return;
    const radius=clamp((aa.scale+bb.scale)/2*r,1,240);
    shapes.push({kind:'capsule',a:aa,b:bb,rx:radius,ry:radius,depth:relief,tone,body:role!==0,role,layer:layer(a)+offset});
  };
  const ellipse=(at:V3,rx:number,ry:number,relief:number,tone:number,role:number,offset=0)=>{
    const q=p(at);if(q.depth<45)return;
    shapes.push({kind:'ellipse',a:q,b:q,rx:Math.max(2,rx*q.scale),ry:Math.max(2,ry*q.scale),depth:relief,tone,body:role!==0,role,layer:layer(at)+offset});
  };
  const line=(v:V3[],role:number,width=2,alpha=.55)=>{
    if(v.some(a=>p(a).depth<45))return;
    const pts=v.map(p);if(pts.every(a=>a.x<0)||pts.every(a=>a.x>1920)||pts.every(a=>a.y<0)||pts.every(a=>a.y>1080))return;
    marks.push({points:pts,role,width,alpha});
  };
  return {p,poly,capsule,ellipse,line,layer};
}
