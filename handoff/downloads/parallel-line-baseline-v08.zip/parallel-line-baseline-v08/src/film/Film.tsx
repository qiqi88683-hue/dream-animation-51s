import React,{useLayoutEffect,useRef} from 'react';
import {AbsoluteFill,Audio,staticFile,useCurrentFrame,delayRender,continueRender,cancelRender} from 'remotion';
import {createFieldFromShapes,fieldSample,NX,NY,DX,DY,H,W,LINE_SPACING,type P} from '../parallel/field';
import {filmScene,FILM_PALETTE} from './scene';
import type {PhoneUI} from './pov';
import {smooth,clamp} from '../timeline';
import {endingAt,signalEnding} from './ending';

export const PAPER='#c8d0ca';
export function drawFilm(ctx:CanvasRenderingContext2D,frame:number,_captions=false){
  const scene=filmScene(frame),field=createFieldFromShapes(scene.shapes,scene.frame);
  ctx.fillStyle=PAPER;ctx.fillRect(0,0,W,H);ctx.lineCap='round';ctx.lineJoin='round';
  const stroke=(points:P[])=>{
    if(points.length<2)return;ctx.beginPath();ctx.moveTo(points[0].x,points[0].y);
    for(let i=1;i<points.length-1;i++)ctx.quadraticCurveTo(points[i].x,points[i].y,(points[i].x+points[i+1].x)/2,(points[i].y+points[i+1].y)/2);
    ctx.lineTo(points.at(-1)!.x,points.at(-1)!.y);ctx.stroke();
  };
  for(let row=0;row<=H/LINE_SPACING;row++){
    const y=row*LINE_SPACING,points=Array.from({length:NX},(_,i)=>({x:i*DX,y:fieldSample(field.flow,i,y)}));
    ctx.strokeStyle=FILM_PALETTE[0];ctx.lineWidth=3.35;ctx.globalAlpha=.78;stroke(points);
    let part:P[]=[],lastRole=0;
    const finish=()=>{ctx.strokeStyle=FILM_PALETTE[lastRole]??FILM_PALETTE[0];ctx.lineWidth=lastRole===1||lastRole===4?4:3.5;ctx.globalAlpha=lastRole===1||lastRole===4?.98:.88;stroke(part);part=[];};
    for(let i=0;i<NX;i++){
      const role=fieldSample(field.coverage,i,y)>.24?Math.round(fieldSample(field.role,i,y)):0;
      if(role!==lastRole){if(part.length)part.push(points[i]);finish();lastRole=role;if(role&&i)part.push(points[i-1]);}
      if(role)part.push(points[i]);
    }finish();
  }
  // Test visibility in rendered curve coordinates so background seam marks
  // cannot draw through foreground people, the phone or the protagonist.
  const ownerAt=(p:P)=>{
    const x=clamp(Math.round(p.x/DX),0,NX-1);let lo=0,hi=NY-1;
    while(hi-lo>1){const mid=(lo+hi)>>1;if(field.flow[mid*NX+x]<p.y)lo=mid;else hi=mid;}
    const at=(Math.abs(field.flow[lo*NX+x]-p.y)<Math.abs(field.flow[hi*NX+x]-p.y)?lo:hi)*NX+x;
    return field.coverage[at]<.24?0:field.role[at];
  };
  for(const mark of scene.marks){
    ctx.strokeStyle=FILM_PALETTE[mark.role]??FILM_PALETTE[0];ctx.lineWidth=mark.width;ctx.globalAlpha=mark.alpha??.8;
    let part:P[]=[];
    for(let i=0;i<mark.points.length-1;i++){
      const a=mark.points[i],b=mark.points[i+1],steps=Math.max(1,Math.ceil(Math.hypot(b.x-a.x,b.y-a.y)/5));
      for(let k=0;k<=steps;k++){
        const p={x:a.x+(b.x-a.x)*k/steps,y:a.y+(b.y-a.y)*k/steps};
        const owner=ownerAt(p);
        if((mark.clipY===undefined||p.y<=mark.clipY)&&(owner===0||owner===mark.role))part.push(p);else{stroke(part);part=[];}
      }
    }stroke(part);
  }
  ctx.globalAlpha=1;
  if(scene.phone){
    // Keep thumb and right index in front of the interface at the contact point.
    const p=scene.phone;ctx.save();ctx.beginPath();
    for(let y=Math.max(0,p.center.y-p.height*.6);y<Math.min(H,p.center.y+p.height*.6);y+=4)
      for(let x=Math.max(0,p.center.x-p.width*.7);x<Math.min(W,p.center.x+p.width*.7);x+=4)
        if(ownerAt({x:x+2,y:y+2})!==1)ctx.rect(x,y,4.2,4.2);
    ctx.clip();phoneUI(ctx,p);ctx.restore();
  }
  if(frame>=1380){
    signalEnding(ctx,frame);
    const fade=endingAt(frame).fade;
    const pixels=ctx.getImageData(0,0,W,H),d=pixels.data;
    for(let i=0;i<d.length;i+=4){const grey=d[i]*.2126+d[i+1]*.7152+d[i+2]*.0722;for(let k=0;k<3;k++)d[i+k]=d[i+k]+(grey-d[i+k])*smooth(fade*2);}
    ctx.putImageData(pixels,0,0);ctx.fillStyle='#fff';ctx.globalAlpha=fade;ctx.fillRect(0,0,W,H);ctx.globalAlpha=1;
  }
}

export function phoneUI(ctx:CanvasRenderingContext2D,p:PhoneUI){
  const w=p.width,h=p.height;
  ctx.save();ctx.translate(p.center.x,p.center.y);ctx.rotate(p.angle);
  ctx.strokeStyle='#2b4652';ctx.fillStyle='#304b58';ctx.lineWidth=3.5;
  ctx.beginPath();ctx.roundRect(-w/2,-h/2,w,h,22);ctx.stroke();
  ctx.lineWidth=2;ctx.beginPath();ctx.roundRect(-w/2+9,-h/2+10,w-18,h-23,16);ctx.stroke();
  ctx.beginPath();ctx.moveTo(-25,-h/2+22);ctx.lineTo(25,-h/2+22);ctx.stroke();
  const label=(text:string,x:number,y:number,size:number)=>{
    ctx.font=`${size}px FilmChinese, sans-serif`;ctx.textAlign='center';ctx.textBaseline='middle';
    const tw=ctx.measureText(text).width;
    ctx.fillStyle=PAPER;ctx.globalAlpha=.91;ctx.fillRect(x-tw/2-4,y-size*.57,tw+8,size*1.14);ctx.globalAlpha=1;ctx.fillStyle='#304b58';ctx.fillText(text,x,y);
  };
  if(p.state==='incoming'){
    // The obscured caller area contains abstract smudges, never digits.
    ctx.save();ctx.fillStyle=PAPER;ctx.globalAlpha=.9;ctx.fillRect(-87,-h*.26-18,174,36);
    ctx.filter='blur(7px)';ctx.fillStyle='#304b58';ctx.globalAlpha=.7;
    for(const [x,y,ww,hh] of [[-65,-h*.26-5,49,10],[-6,-h*.26-6,71,12],[-42,-h*.26+3,83,7]]){ctx.beginPath();ctx.roundRect(x,y,ww,hh,5);ctx.fill();}
    ctx.restore();label('来电',0,-h*.16,16);
    ctx.beginPath();ctx.arc(0,-8,27,0,Math.PI*2);ctx.stroke();ctx.beginPath();ctx.arc(0,-15,8,0,Math.PI*2);ctx.stroke();
    ctx.beginPath();ctx.moveTo(-16,10);ctx.quadraticCurveTo(0,-8,16,10);ctx.stroke();
    ctx.fillStyle='#9b635e';ctx.globalAlpha=.88;ctx.beginPath();ctx.arc(0,h*.285,29,0,Math.PI*2);ctx.fill();ctx.globalAlpha=1;
    ctx.strokeStyle='#e0e4da';ctx.lineWidth=4;ctx.beginPath();ctx.moveTo(-15,h*.285+2);ctx.quadraticCurveTo(0,h*.285-10,15,h*.285+2);ctx.stroke();
    label('拒绝',0,h*.405,15);
  }else{
    label(p.state==='music'?'正在播放':'通话已结束',0,-h*.285,19);
    ctx.strokeStyle='#55747b';ctx.lineWidth=2.5;
    for(let i=0;i<10;i++){ctx.beginPath();ctx.moveTo(-66,-h*.16+i*9);ctx.bezierCurveTo(-18,-h*.24+i*9,30,-h*.09+i*9,66,-h*.16+i*9);ctx.stroke();}
    ctx.beginPath();ctx.moveTo(-72,h*.17);ctx.lineTo(72,h*.17);ctx.stroke();
    ctx.beginPath();ctx.arc(-23,h*.17,3.5,0,Math.PI*2);ctx.fillStyle='#304b58';ctx.fill();
    ctx.strokeStyle='#304b58';ctx.lineWidth=4;ctx.beginPath();
    if(p.state==='music'){ctx.moveTo(-7,h*.27);ctx.lineTo(-7,h*.34);ctx.moveTo(7,h*.27);ctx.lineTo(7,h*.34);}
    else{ctx.moveTo(-7,h*.27);ctx.lineTo(10,h*.305);ctx.lineTo(-7,h*.34);ctx.closePath();}
    ctx.stroke();label(p.state==='music'?'耳机播放':'音乐已暂停',0,h*.41,14);
  }
  ctx.restore();
}

export const Film:React.FC<{startFrame:number;sound:boolean;captions:boolean}>=({startFrame,sound,captions})=>{
  const frame=useCurrentFrame()+startFrame,canvas=useRef<HTMLCanvasElement>(null);
  useLayoutEffect(()=>{
    const handle=delayRender('Chinese font and deterministic line-field frame');
    document.fonts.load('24px FilmChinese').then(()=>{if(canvas.current)drawFilm(canvas.current.getContext('2d')!,frame,captions);continueRender(handle);}).catch(cancelRender);
  },[frame,captions]);
  return <AbsoluteFill><style>{`@font-face{font-family:FilmChinese;src:url('${staticFile('fonts/NotoSansCJKsc-Regular.otf')}') format('opentype');font-display:block}`}</style>
    <canvas ref={canvas} width={W} height={H} style={{width:'100%',height:'100%'}}/>
    {sound&&<Audio src={staticFile('audio/film-v08/full-mix.wav')} trimBefore={startFrame}/>}
  </AbsoluteFill>;
};
