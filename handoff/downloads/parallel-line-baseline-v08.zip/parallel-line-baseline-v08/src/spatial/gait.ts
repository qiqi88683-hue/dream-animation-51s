import {smooth} from '../timeline';
export type V={x:number;y:number;z:number};
export const CYCLE=1.12;
export const STANCE=.62;
export const THIGH=.48;
export const SHIN=.47;
export function footPose(t:number,leg:number,speed:number){
  const cycle=t/CYCLE+leg*.5,phase=cycle-Math.floor(cycle),distance=speed*CYCLE;
  const swing=Math.max(0,(phase-STANCE)/(1-STANCE));
  const advance=phase<STANCE?0:smooth(swing);
  return {phase,stance:phase<STANCE,z:distance*(.31+advance-phase),
    y:.065+(phase<STANCE?0:Math.sin(Math.PI*swing)*.115),
    roll:phase<.12?-.13*(1-phase/.12):phase>.50&&phase<STANCE?.2*(phase-.50)/.12:0};
}
export function twoBone(start:V,end:V,a:number,b:number,bendSign:1|-1=1):V{
  const dy=end.y-start.y,dz=end.z-start.z,d=Math.hypot(dy,dz);
  if(d>=a+b||d<=Math.abs(a-b))throw new Error(`Unreachable joint distance ${d}`);
  const along=(a*a-b*b+d*d)/(2*d),perp=Math.sqrt(Math.max(0,a*a-along*along));
  return {x:start.x,y:start.y+dy/d*along+bendSign*dz/d*perp,z:start.z+dz/d*along-bendSign*dy/d*perp};
}
export function gaitPose(t:number,speed=.95){
  const angle=t/CYCLE*Math.PI*2,pelvis=.93+Math.cos(angle*2)*.012;
  const legs=[0,1].map(i=>{
    const x=i===0?-.095:.095,foot=footPose(t,i,speed);
    const hip={x,y:pelvis,z:0},ankle={x,y:foot.y,z:foot.z};
    return {hip,knee:twoBone(hip,ankle,THIGH,SHIN),ankle,...foot};
  });
  const arms=[0,1].map(i=>{
    const sign=i===0?-1:1,x=sign*.215;
    const shoulder={x,y:pelvis+.55,z:.012},hand={x,y:pelvis+.035,z:Math.cos(angle+i*Math.PI)*-.15};
    return {shoulder,elbow:twoBone(shoulder,hand,.29,.28,-1),hand};
  });
  return {pelvis,legs,arms,angle};
}
