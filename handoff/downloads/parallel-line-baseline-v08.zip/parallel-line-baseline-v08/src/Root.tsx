import React from 'react';
import {Composition} from 'remotion';
import {Film} from './film/Film';
import {ParallelPreview} from './parallel/ParallelPreview';
import {GaitCheck} from './parallel/GaitCheck';
import {DetailColorPreview} from './detail/DetailColorPreview';
import {SHOTS,TOTAL_FRAMES,FPS,WIDTH,HEIGHT} from './timeline';
export const Root:React.FC=()=> <>
  <Composition id="FilmFull" component={Film} width={WIDTH} height={HEIGHT} fps={FPS} durationInFrames={TOTAL_FRAMES} defaultProps={{startFrame:0,sound:true,captions:false}}/>
  {SHOTS.map(shot=><Composition key={shot.id} id={`Film${shot.id}`} component={Film} width={WIDTH} height={HEIGHT} fps={FPS} durationInFrames={shot.frames} defaultProps={{startFrame:shot.start,sound:false,captions:false}}/>)}
  <Composition id="DetailColorPreview" component={DetailColorPreview} width={WIDTH} height={HEIGHT} fps={FPS} durationInFrames={270} defaultProps={{handOnly:false}}/>
  <Composition id="HandDetailPreview" component={DetailColorPreview} width={WIDTH} height={HEIGHT} fps={FPS} durationInFrames={180} defaultProps={{handOnly:true}}/>
  <Composition id="ParallelPreview" component={ParallelPreview} width={WIDTH} height={HEIGHT} fps={FPS} durationInFrames={240} defaultProps={{mono:false,portrait:false}}/>
  <Composition id="ParallelPortrait" component={ParallelPreview} width={WIDTH} height={HEIGHT} fps={FPS} durationInFrames={1} defaultProps={{mono:true,portrait:true}}/>
  <Composition id="GaitCheck" component={GaitCheck} width={WIDTH} height={HEIGHT} fps={FPS} durationInFrames={1}/>

</>;
