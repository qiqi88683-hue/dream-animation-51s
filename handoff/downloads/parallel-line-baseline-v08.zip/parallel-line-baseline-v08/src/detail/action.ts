import {smooth,clamp,mix} from '../timeline';
import {gaitPose,twoBone,type V} from '../spatial/gait';

export const DETAIL_START=90;
export const DETAIL_FRAMES=180;
export const COLOR_PREVIEW_FRAMES=270;
export const PHONE_HEIGHT=.155;
export const PHONE_WIDTH=.074;
export const POCKET_MOUTH=.975;
export type PhonePhase='reach'|'extract'|'read'|'return'|'release';

export function phoneAction(frame:number){
  const f=clamp(frame,0,179);
  const phase:PhonePhase=f<24?'reach':f<66?'extract':f<112?'read':f<154?'return':'release';
  const lift=f<24?0:f<66?smooth((f-24)/42):f<112?1:f<154?1-smooth((f-112)/42):0;
  const reach=smooth(f/24)*(1-smooth((f-154)/25));
  const top=mix(.965,1.31,lift);
  const grip:V={x:.215,y:top-mix(.025,.10,lift),z:mix(.055,.32,lift)};
  const wrist:V={x:.215,y:mix(.965,grip.y,reach),z:mix(-.07,grip.z,reach)};
  const phone={id:'hero-phone',center:{x:.215,y:top-PHONE_HEIGHT/2,z:grip.z+.055},top,bottom:top-PHONE_HEIGHT,
    exposed:clamp((top-POCKET_MOUTH)/PHONE_HEIGHT),angle:.12};
  const gaze=smooth((f-48)/18)*(1-smooth((f-112)/30));
  const pose=gaitPose(.1,.95);
  pose.pelvis=.93;
  const leftShoulder={x:.215,y:1.48,z:.012};
  pose.arms[1]={shoulder:leftShoulder,elbow:twoBone(leftShoulder,wrist,.29,.28,-1),hand:wrist};
  const rightShoulder={x:-.215,y:1.48,z:.012},rightHand={x:-.215,y:.965,z:-.055};
  pose.arms[0]={shoulder:rightShoulder,elbow:twoBone(rightShoulder,rightHand,.29,.28,-1),hand:rightHand};
  return {frame:f,phase,lift,reach,gaze,pose,phone,wrist,gripping:f>=24&&f<154};
}
