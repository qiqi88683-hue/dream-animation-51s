import React,{useLayoutEffect,useRef} from 'react';
import {AbsoluteFill,Audio,staticFile,useCurrentFrame} from 'remotion';
import {createFieldFromShapes,fieldSample,NX,DX,H,W,LINE_SPACING,type P} from '../parallel/field';
import {detailedScene,colorForRole,INKS} from './scene';

export function drawDetail(ctx:CanvasRenderingContext2D,frame:number,handOnly=false){
  const scene=detailedScene(frame,handOnly),field=createFieldFromShapes(scene.shapes,frame);
  ctx.fillStyle=INKS.paper;ctx.fillRect(0,0,W,H);
  ctx.lineCap='round';ctx.lineJoin='round';
  const stroke=(points:P[])=>{
    if(points.length<2)return;ctx.beginPath();ctx.moveTo(points[0].x,points[0].y);
    for(let i=1;i<points.length-1;i++)ctx.quadraticCurveTo(points[i].x,points[i].y,(points[i].x+points[i+1].x)/2,(points[i].y+points[i+1].y)/2);
    ctx.lineTo(points.at(-1)!.x,points.at(-1)!.y);ctx.stroke();
  };
  // Preserve the approved continuous family. Color only follows ownership along
  // these same curves; there are no opaque silhouettes or painted textures.
  for(let row=0;row<=H/LINE_SPACING;row++){
    const y=row*LINE_SPACING,points=Array.from({length:NX},(_,i)=>({x:i*DX,y:fieldSample(field.flow,i,y)}));
    ctx.strokeStyle=INKS.background;ctx.lineWidth=3.35;ctx.globalAlpha=.78;stroke(points);
    let part:P[]=[],lastRole=0;
    const finish=()=>{ctx.strokeStyle=colorForRole(lastRole);ctx.lineWidth=4;ctx.globalAlpha=.98;stroke(part);part=[];};
    for(let i=0;i<NX;i++){
      const role=fieldSample(field.coverage,i,y)>.24?Math.round(fieldSample(field.role,i,y)):0;
      if(role!==lastRole){if(part.length)part.push(points[i]);finish();lastRole=role;if(role&&i)part.push(points[i-1]);}
      if(role)part.push(points[i]);
    }finish();
  }
  // A few local seams/knuckles make fine actions readable without replacing
  // the line-density volumes with a conventional outlined cartoon.
  ctx.globalAlpha=.88;ctx.strokeStyle=INKS.detail;ctx.lineWidth=2.7;
  for(const accent of scene.accents){
    if(accent.kind==='curve'){stroke(accent.points);continue;}
    ctx.save();
    if(accent.clipY!==undefined){ctx.beginPath();ctx.rect(0,0,W,accent.clipY);ctx.clip();}
    const c=accent.points[0],w=accent.width!,h=accent.height!;
    ctx.translate(c.x,c.y);ctx.rotate(accent.angle??0);
    ctx.strokeStyle=INKS.phone;ctx.lineWidth=3.4;
    ctx.beginPath();ctx.roundRect(-w/2,-h/2,w,h,w*.12);ctx.stroke();
    ctx.lineWidth=2.2;ctx.beginPath();ctx.roundRect(-w*.38,-h*.39,w*.76,h*.76,w*.07);ctx.stroke();
    ctx.beginPath();ctx.moveTo(-w*.10,-h*.44);ctx.lineTo(w*.10,-h*.44);ctx.moveTo(-w*.13,h*.43);ctx.lineTo(w*.13,h*.43);ctx.stroke();
    ctx.restore();
  }
  ctx.globalAlpha=1;
}

export const DetailColorPreview:React.FC<{handOnly:boolean}>=({handOnly})=>{
  const frame=useCurrentFrame(),canvas=useRef<HTMLCanvasElement>(null);
  useLayoutEffect(()=>{if(canvas.current)drawDetail(canvas.current.getContext('2d')!,frame,handOnly);},[frame,handOnly]);
  return <AbsoluteFill><canvas ref={canvas} width={W} height={H} style={{width:'100%',height:'100%'}}/>
    <Audio src={staticFile('audio/generated/city-placeholder.wav')} volume={.16}/>
  </AbsoluteFill>;
};
