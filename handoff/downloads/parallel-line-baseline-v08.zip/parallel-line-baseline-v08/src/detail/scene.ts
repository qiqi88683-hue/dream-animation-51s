import {gaitPose,type V} from '../spatial/gait';
import {DETAIL_START,PHONE_HEIGHT,PHONE_WIDTH,POCKET_MOUTH,phoneAction} from './action';
import {makeShapes,type Shape,type P} from '../parallel/field';

export const INKS={paper:'#c8d0ca',background:'#86948d',hero:'#355d6b',passer1:'#827466',passer2:'#718375',phone:'#263f4b',detail:'#304f5c'};
export type View={scale:number;rootX:number;ground:number;facing:number;project:(p:V)=>P};
function view(scale:number,rootX:number,ground:number,facing=-1):View{
  return {scale,rootX,ground,facing,project:v=>({x:rootX+facing*v.z*scale+v.x*scale*.22,y:ground-v.y*scale})};
}
type Accent={kind:'curve'|'phone';points:P[];angle?:number;width?:number;height?:number;clipY?:number};
export type DetailScene={shapes:Shape[];accents:Accent[];phase:string;action:ReturnType<typeof phoneAction>|null;view:View};

export function detailedScene(frame:number,handOnly=false):DetailScene{
  const close=handOnly||frame>=DETAIL_START,local=handOnly?frame:frame-DETAIL_START;
  const shapes:Shape[]=close?[]:makeShapes(frame).filter(s=>!s.body);
  const accents:Accent[]=[];
  const action=close?phoneAction(local):null;
  const mainView=close?(handOnly?view(1700,1650,2600):view(720,1110,1530)):view(340,1260-frame/30*.95*340*.2,1000);

  function actor(pose:ReturnType<typeof gaitPose>,v:View,role:number,layer:number,details:boolean){
    const s=v.scale,p=v.project;
    const ellipse=(a:P,rx:number,ry:number,depth:number,tone:number,extra:Partial<Shape>={})=>shapes.push({kind:'ellipse',a,b:a,rx,ry,depth,tone,body:true,role,layer,...extra});
    const capsule=(a:P,b:P,r:number,depth:number,tone:number,extra:Partial<Shape>={})=>shapes.push({kind:'capsule',a,b,rx:r,ry:r,depth,tone,body:true,role,layer,...extra});
    for(const i of [0,1]){
      const leg=pose.legs[i];capsule(p(leg.hip),p(leg.knee),s*.058,.90,.75);capsule(p(leg.knee),p(leg.ankle),s*.041,.85,.78);
      const a=p(leg.ankle);ellipse({x:a.x+v.facing*s*.045,y:a.y+s*.025},s*.116,s*.035,.58,.53);
    }
    ellipse(p({x:0,y:pose.pelvis+.285,z:.008}),s*.142,s*.320,1.14,.72);
    capsule(p({x:0,y:pose.pelvis+.57,z:.008}),p({x:0,y:pose.pelvis+.67,z:.015}),s*.035,.90,.40);
    const tilt=details&&action?-.20*action.gaze:0;
    const head=p({x:0,y:pose.pelvis+.78-.012*(action?.gaze??0),z:.012+.04*(action?.gaze??0)});
    const hp=(x:number,y:number)=>({x:head.x+x*Math.cos(tilt)-y*Math.sin(tilt),y:head.y+x*Math.sin(tilt)+y*Math.cos(tilt)});
    ellipse(head,s*.073,s*.118,.96,.38,{angle:tilt});
    ellipse(hp(v.facing*s*.068,s*.002),s*.031,s*.019,.70,.34,{angle:tilt});
    ellipse(hp(v.facing*s*.029,s*.072),s*.045,s*.037,.72,.32,{angle:tilt});
    ellipse(hp(-v.facing*s*.007,-s*.066),s*.079,s*.062,1.05,.91,{angle:tilt});
    if(role===3)ellipse(hp(-v.facing*s*.079,-s*.035),s*.027,s*.031,.82,.78);
    if(details){
      const eyes=[hp(v.facing*s*.066,-s*.023),hp(v.facing*s*.005,-s*.020),hp(v.facing*s*.008,s*.009),hp(v.facing*s*.061,s*.008)];
      for(let i=0;i<3;i++)capsule(eyes[i],eyes[i+1],s*.004,.035,.93,{detail:true});
      accents.push({kind:'curve',points:[eyes[0],eyes[1],eyes[2],eyes[3],eyes[0]]});
      const nose=hp(v.facing*s*.078,s*.022),chin=hp(v.facing*s*.043,s*.074);
      accents.push({kind:'curve',points:[nose,hp(v.facing*s*.064,s*.047),chin]});
      const collar=p({x:0,y:pose.pelvis+.56,z:.045});
      accents.push({kind:'curve',points:[{x:collar.x+s*.04,y:collar.y-s*.015},collar,{x:collar.x+s*.015,y:collar.y+s*.05}]});
    }
    for(const i of [0,1]){
      const arm=pose.arms[i],near=i===1,armLayer=layer+(near?.20:-.05);
      capsule(p(arm.shoulder),p(arm.elbow),s*.031,near?1.13:.78,.32,{layer:armLayer});
      const sleeve={x:arm.shoulder.x,y:arm.shoulder.y+(arm.elbow.y-arm.shoulder.y)*.46,z:arm.shoulder.z+(arm.elbow.z-arm.shoulder.z)*.46};
      capsule(p(arm.shoulder),p(sleeve),s*.051,near?1.18:.83,.66,{layer:armLayer});
      capsule(p(arm.elbow),p(arm.hand),s*.024,near?1.07:.77,.33,{layer:armLayer});
      const turn=near&&action?action.reach*action.lift:0;
      const palmEnd={...arm.hand,y:arm.hand.y-.080+turn*.145,z:arm.hand.z+turn*.018};
      capsule(p(arm.hand),p(palmEnd),s*.020,near?1.09:.79,.35,{layer:armLayer});
      if(details&&near){
        const wrist=p({x:arm.hand.x,y:arm.hand.y+(arm.elbow.y-arm.hand.y)*.12,z:arm.hand.z+(arm.elbow.z-arm.hand.z)*.12});
        ellipse(wrist,s*.028,s*.014,.065,.97,{detail:true,layer:armLayer+.02,feature:'left-watch'});
        accents.push({kind:'curve',points:[{x:wrist.x-s*.025,y:wrist.y-s*.008},{x:wrist.x+s*.024,y:wrist.y-s*.009},{x:wrist.x+s*.026,y:wrist.y+s*.009},{x:wrist.x-s*.023,y:wrist.y+s*.011},{x:wrist.x-s*.025,y:wrist.y-s*.008}]});
        if(close){
          const hand=p(palmEnd);
          for(let finger=0;finger<4;finger++){
            const base={x:hand.x+s*.012,y:hand.y+s*(.025+finger*.011)};
            const tip={x:hand.x-s*(.022-finger*.002),y:base.y+s*.008};
            capsule(base,tip,s*.0055,.12,.38,{layer:armLayer+.05,detail:true,feature:'left-fingers'});
            accents.push({kind:'curve',points:[base,{x:hand.x-s*.004,y:base.y-s*.003},tip]});
          }
        }
      }
    }
    if(details){
      const a=p({x:.215,y:POCKET_MOUTH,z:.015}),b=p({x:.215,y:.915,z:.105});
      capsule(a,b,s*.004,.04,.89,{detail:true,feature:'left-pocket'});
      accents.push({kind:'curve',points:[a,{x:(a.x+b.x)/2-s*.008,y:(a.y+b.y)/2},b]});
    }
  }

  if(!close){
    const t=frame/30;
    actor(gaitPose(t+.3,.80),view(304,650+t*150,938,1),2,1,false);
    actor(gaitPose(t,.95),mainView,1,2,true);
    actor(gaitPose(t+.55,.86),view(324,1850-t*190,1060),3,3,false);
  }else{
    actor(action!.pose,mainView,1,2,true);
    const state=action!,s=mainView.scale,c=mainView.project(state.phone.center),opening=mainView.project({x:.215,y:POCKET_MOUTH,z:.055}).y;
    if(state.phone.exposed>0){
      const w=PHONE_WIDTH*s,h=PHONE_HEIGHT*s;
      shapes.push({kind:'rect',a:{x:c.x-w/2,y:c.y-h/2},b:{x:c.x+w/2,y:c.y+h/2},rx:0,ry:0,depth:.48,tone:.88,body:true,role:4,layer:2.12,angle:state.phone.angle,clipY:opening,feature:'phone'});
      accents.push({kind:'phone',points:[c],width:w,height:h,angle:state.phone.angle,clipY:opening});
    }
  }
  return {shapes,accents,phase:action?.phase??'walk',action,view:mainView};
}

export function colorForRole(role:number){return role===1?INKS.hero:role===2?INKS.passer1:role===3?INKS.passer2:role===4?INKS.phone:INKS.background;}
