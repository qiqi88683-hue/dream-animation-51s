# 可恢复的平行曲线工程基线 v08

这是已完成作品的精简复现夹具，用于复用渲染与动作机制。它没有实现任意分镜JSON自动成片；新项目必须适配剧情层。先读handoff/HANDOFF_GUIDE.md。

需要Node >=22、Python 3.12、FFmpeg/ffprobe、Chrome或Chromium。执行npm ci、npm run typecheck、npm test。Linux自动使用/usr/bin/chromium；其他路径设置REMOTION_BROWSER_EXECUTABLE。Mac尚未实机验证。

关键帧：npm run render:film -- --quick。全片复现：npm run render:film。样式检查：npm run render:parallel -- --quick。本包已带字体、现有混音和非人声分轨，画面验证无需重新生成声音或下载TTS模型。

重建音频：python3 -m venv .venv-audio，激活后pip install -r requirements-audio.txt，再npm run audio:film。无需密钥。原始高码率视频输出在out/film-v08；以ffprobe检查实际规格。

保留生产线场、骨架、摄影机、v08剧情夹具、声音及已认可的短样入口与测试。Root.tsx只注册这些入口；package.json只保留对应命令。依赖版本和package-lock沿用原工程，历史兼容依赖尚未进一步削减。早期油画/矢量试验未打入本包。

原repo的发布打包脚本依赖历史目录，因此本包不提供它们；它可独立生成画面与混音，新项目按交接手册导出自己的发布结构。FILE_MANIFEST.json记录全部文件SHA-256。字体许可证在public/fonts；人物、城市、无对白和白场结尾都是夹具内容，不是新项目默认剧情。
